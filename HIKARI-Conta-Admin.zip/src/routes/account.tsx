import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { signOut } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { isHikariAdminEmail } from "@/lib/auth/admin";

export const Route = createFileRoute("/account")({
  component: AccountPage,
});

function AccountPage() {
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [busy, setBusy] = useState(false);

  if (isPending) return null;
  if (!user) {
    return (
      <section className="mx-auto max-w-md py-12 text-center">
        <h1 className="text-2xl font-semibold">Sua conta</h1>
        <p className="mt-2 text-sm text-muted">Entre ou crie uma conta para continuar.</p>
        <Link to="/login" className="mt-6 inline-flex rounded-md bg-fg px-5 py-3 text-sm font-medium text-bg">
          Entrar / Criar conta
        </Link>
      </section>
    );
  }

  const admin = isHikariAdminEmail(user.primaryEmail);
  async function logout() {
    setBusy(true);
    try {
      await signOut();
      await navigate({ to: "/" });
      window.location.reload();
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="mx-auto max-w-2xl py-8">
      <div className="rounded-2xl border border-border bg-elevated p-6">
        <h1 className="text-2xl font-semibold">Minha conta</h1>
        <div className="mt-6 flex items-center gap-4">
          {user.profileImageUrl ? (
            <img src={user.profileImageUrl} alt="" className="size-14 rounded-full object-cover" />
          ) : (
            <div className="grid size-14 place-items-center rounded-full bg-black/10 text-xl dark:bg-white/10">
              {(user.displayName ?? user.primaryEmail ?? "U").charAt(0).toUpperCase()}
            </div>
          )}
          <div>
            <p className="font-medium">{user.displayName ?? "Usuário"}</p>
            <p className="text-sm text-muted">{user.primaryEmail}</p>
          </div>
        </div>

        {admin && (
          <Link to="/admin" className="mt-6 block rounded-lg border border-border p-4 hover:bg-bg">
            <p className="font-medium">🔐 Painel Admin</p>
            <p className="mt-1 text-sm text-muted">Gerenciar animes, episódios e players.</p>
          </Link>
        )}

        <button
          type="button"
          disabled={busy}
          onClick={() => void logout()}
          className="mt-6 rounded-md border border-border px-4 py-2 text-sm"
        >
          {busy ? "Saindo..." : "Sair da conta"}
        </button>
      </div>
    </section>
  );
}
