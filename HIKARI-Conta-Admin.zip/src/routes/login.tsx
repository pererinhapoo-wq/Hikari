import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { authClient, signIn, GROK_PROVIDERS } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/login")({
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  if (!isPending && user) {
    void navigate({ to: "/account", replace: true });
    return null;
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      if (mode === "signup") {
        const result = await authClient.signUp.email({
          email: email.trim(),
          password,
          name: name.trim() || email.split("@")[0],
        });
        if (result.error) throw new Error(result.error.message || "Não foi possível criar a conta.");
      } else {
        const result = await authClient.signIn.email({
          email: email.trim(),
          password,
        });
        if (result.error) throw new Error(result.error.message || "E-mail ou senha incorretos.");
      }
      await navigate({ to: "/account", replace: true });
      window.location.reload();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Não foi possível entrar.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="mx-auto flex min-h-[70dvh] w-full max-w-md items-center justify-center py-10">
      <div className="w-full rounded-2xl border border-border bg-elevated p-6 shadow-sm">
        <h1 className="text-2xl font-semibold">Conta HIKARI</h1>
        <p className="mt-1 text-sm text-muted">
          {mode === "login" ? "Entre na sua conta." : "Crie sua conta para usar o HIKARI."}
        </p>

        <form onSubmit={submit} className="mt-6 space-y-3">
          {mode === "signup" && (
            <input
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Nome"
              className="h-11 w-full rounded-md border border-border bg-bg px-3 outline-none"
            />
          )}
          <input
            required
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="E-mail"
            className="h-11 w-full rounded-md border border-border bg-bg px-3 outline-none"
          />
          <input
            required
            minLength={8}
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Senha (mínimo 8 caracteres)"
            className="h-11 w-full rounded-md border border-border bg-bg px-3 outline-none"
          />
          {error && <p className="text-sm text-red-500">{error}</p>}
          <button
            disabled={busy}
            className="h-11 w-full rounded-md bg-fg px-4 text-sm font-medium text-bg disabled:opacity-60"
          >
            {busy ? "Aguarde..." : mode === "login" ? "Entrar" : "Criar conta"}
          </button>
        </form>

        <div className="my-5 flex items-center gap-3 text-xs text-subtle">
          <span className="h-px flex-1 bg-border" /><span>ou</span><span className="h-px flex-1 bg-border" />
        </div>

        <div className="space-y-2">
          {GROK_PROVIDERS.map((p) => (
            <button
              key={p.providerId}
              type="button"
              onClick={() => void signIn(p.providerId, { callbackURL: "/account" })}
              className="h-11 w-full rounded-md border border-border px-4 text-sm hover:bg-bg"
            >
              Continuar com {p.label}
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={() => { setMode(mode === "login" ? "signup" : "login"); setError(""); }}
          className="mt-5 w-full text-sm text-muted underline underline-offset-4"
        >
          {mode === "login" ? "Ainda não tenho conta" : "Já tenho uma conta"}
        </button>
        <Link to="/" className="mt-4 block text-center text-sm text-muted">Voltar ao início</Link>
      </div>
    </section>
  );
}
