import { Outlet, createFileRoute, Navigate } from "@tanstack/react-router";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { isHikariAdminEmail } from "@/lib/auth/admin";
import { SIGN_IN_PATH } from "@/lib/auth/gates";

export const Route = createFileRoute("/admin")({
  component: AdminGuard,
});

function AdminGuard() {
  const { user, isPending } = useCurrentUserState();

  if (isPending) return null;
  if (!user) return <Navigate to={SIGN_IN_PATH} />;
  if (!isHikariAdminEmail(user.primaryEmail)) return <Navigate to="/" />;

  return <Outlet />;
}
