import { useCurrentUser } from "./use-current-user";

export const HIKARI_ADMIN_EMAIL = "matheussilva65554@gmail.com";

export function isHikariAdminEmail(email: string | null | undefined): boolean {
  return email?.trim().toLowerCase() === HIKARI_ADMIN_EMAIL;
}

export function useIsHikariAdmin(): boolean {
  const user = useCurrentUser();
  return isHikariAdminEmail(user?.primaryEmail);
}
