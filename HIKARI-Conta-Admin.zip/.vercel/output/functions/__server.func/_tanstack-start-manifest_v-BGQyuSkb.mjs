//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BGQyuSkb.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/my-list",
			"/search",
			"/anime/$id",
			"/browse/$section",
			"/watch/$id"
		],
		preloads: [
			"/assets/index-BFc4EOxP.js",
			"/assets/jsx-runtime-BkSabwWG.js",
			"/assets/useStore-D0ZA7xG-.js",
			"/assets/api-CGCEkLWS.js",
			"/assets/store-Bezt-GmB.js",
			"/assets/not-found-DIgawKw1.js",
			"/assets/matchContext-DnCcktvE.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BFc4EOxP.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Bx2DCq1V.js",
			"/assets/routes-CWVhsd8M.js",
			"/assets/chevron-right-Brwo5nNd.js",
			"/assets/badge-DubOgQvW.js",
			"/assets/button-B9Ol58i_.js",
			"/assets/overlay-DYEnhTyV.js"
		]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: ["/admin/$id", "/admin/"],
		preloads: ["/assets/admin-D98MHsbE.js"]
	},
	"/my-list": {
		filePath: "/workspace/src/routes/my-list.tsx",
		children: void 0,
		preloads: ["/assets/my-list-CRYX3qYR.js"]
	},
	"/search": {
		filePath: "/workspace/src/routes/search.tsx",
		children: void 0,
		preloads: [
			"/assets/search-DWPcs7zD.js",
			"/assets/button-B9Ol58i_.js",
			"/assets/input-BjbTAzCg.js",
			"/assets/native-select-C0jgm0Pt.js",
			"/assets/overlay-DYEnhTyV.js"
		]
	},
	"/admin/$id": {
		filePath: "/workspace/src/routes/admin.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/admin._id-DrhbnZxH.js",
			"/assets/trash-2-CPzQ8ass.js",
			"/assets/button-B9Ol58i_.js",
			"/assets/input-BjbTAzCg.js",
			"/assets/native-select-C0jgm0Pt.js"
		]
	},
	"/anime/$id": {
		filePath: "/workspace/src/routes/anime.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/anime._id-DtrqvxW6.js",
			"/assets/badge-DubOgQvW.js",
			"/assets/button-B9Ol58i_.js",
			"/assets/overlay-DYEnhTyV.js"
		]
	},
	"/browse/$section": {
		filePath: "/workspace/src/routes/browse.$section.tsx",
		children: void 0,
		preloads: ["/assets/browse._section-DhgFkAFC.js", "/assets/overlay-DYEnhTyV.js"]
	},
	"/watch/$id": {
		filePath: "/workspace/src/routes/watch.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/watch._id-BV_UCa91.js",
			"/assets/chevron-right-Brwo5nNd.js",
			"/assets/x-BxVdt0Sz.js",
			"/assets/button-B9Ol58i_.js",
			"/assets/overlay-DYEnhTyV.js"
		]
	},
	"/admin/": {
		filePath: "/workspace/src/routes/admin.index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.index-B0DsxHKc.js",
			"/assets/trash-2-CPzQ8ass.js",
			"/assets/x-BxVdt0Sz.js",
			"/assets/button-B9Ol58i_.js",
			"/assets/input-BjbTAzCg.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
