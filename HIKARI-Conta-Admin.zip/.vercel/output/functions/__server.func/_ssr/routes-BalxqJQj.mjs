import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as scoreLabel, l as genreLabel } from "./labels-C6131ZKr.mjs";
import { a as useHikariStore, n as displayTitle, r as localToAnime } from "./store-Cos-sjSt.mjs";
import { _ as BookmarkCheck, g as Bookmark, l as Play, m as ChevronRight } from "../_libs/lucide-react.mjs";
import { c as HomePending, d as AnimeCardSkeleton, s as Route$8, u as AnimeCard } from "./router-2uA790DW.mjs";
import { t as Button } from "./button-BQS8iGY-.mjs";
import { n as overlayList } from "./overlay-BP0tE_9a.mjs";
import { t as Badge } from "./badge-DFNkFcMp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BalxqJQj.js
var import_jsx_runtime = require_jsx_runtime();
function Hero({ anime }) {
	const title = displayTitle(anime);
	const inList = useHikariStore((s) => s.myList.includes(anime.id));
	const toggleList = useHikariStore((s) => s.toggleList);
	const backdrop = anime.banner || anime.cover;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative -mx-4 min-h-[28rem] overflow-hidden sm:-mx-6 sm:min-h-[34rem] lg:min-h-[38rem]",
		children: [
			backdrop && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: backdrop,
				alt: "",
				className: "absolute inset-0 size-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-t from-bg via-bg/70 to-bg/20" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-r from-bg/90 via-bg/40 to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 flex min-h-[28rem] flex-col justify-end px-4 pb-8 sm:min-h-[34rem] sm:px-6 sm:pb-10 lg:min-h-[38rem]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium tracking-[0.28em] text-muted uppercase",
						children: "Em destaque"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 max-w-2xl font-display text-4xl leading-tight tracking-tight text-fg sm:text-5xl lg:text-6xl",
						children: title
					}),
					anime.titles.native && anime.titles.native !== title && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-sm text-muted",
						children: anime.titles.native
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap items-center gap-2",
						children: [
							anime.score != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium tabular-nums text-score",
								children: scoreLabel(anime.score)
							}),
							anime.year && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: anime.year
							}),
							anime.genres.slice(0, 3).map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: genreLabel(g) }, g))
						]
					}),
					anime.synopsis && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl line-clamp-3 text-sm leading-relaxed text-muted",
						children: anime.synopsis
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/watch/$id",
									params: { id: anime.id },
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), "Assistir"]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "outline",
								size: "lg",
								onClick: () => toggleList(anime),
								children: [inList ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4" }), inList ? "Na lista" : "Minha Lista"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "ghost",
								size: "lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/anime/$id",
									params: { id: anime.id },
									children: "Detalhes"
								})
							})
						]
					})
				]
			})
		]
	});
}
function AnimeRow({ title, href, items, loading }) {
	if (!loading && items.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-end justify-between gap-3 px-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl tracking-tight text-fg sm:text-2xl",
				children: title
			}), href && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: href,
				className: "inline-flex min-h-11 items-center gap-0.5 text-xs font-medium tracking-wide text-muted uppercase hover:text-fg",
				children: ["Ver tudo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-3.5" })]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rail -mx-4 px-4 sm:-mx-6 sm:px-6",
			children: loading ? Array.from({ length: 8 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimeCardSkeleton, {}, i)) : items.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimeCard, { anime: a }, a.id))
		})]
	});
}
function Home() {
	const data = Route$8.useLoaderData();
	const locals = useHikariStore((s) => s.animes);
	const continueWatching = useHikariStore((s) => s.continueWatching);
	const trending = overlayList(data.trending, locals);
	const popular = overlayList(data.popular, locals);
	const top = overlayList(data.top, locals);
	const season = overlayList(data.season, locals);
	const featured = trending[0] ?? popular[0];
	const added = locals.filter((a) => !a.hidden && !a.anilistId).map(localToAnime);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-10 pb-6",
		children: [
			featured ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, { anime: featured }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomePending, {}),
			continueWatching.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl tracking-tight sm:text-2xl",
					children: "Continuar assistindo"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rail -mx-4 px-4 sm:-mx-6 sm:px-6",
					children: continueWatching.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/watch/$id",
						params: { id: c.animeId },
						search: { ep: c.episodeId },
						className: "w-56 shrink-0 overflow-hidden rounded-lg bg-elevated shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "aspect-video bg-surface",
							children: c.cover && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: c.cover,
								alt: "",
								className: "size-full object-cover"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm text-fg",
								children: c.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate text-xs text-muted",
								children: [
									"Ep. ",
									c.episodeNumber,
									" · ",
									c.episodeTitle
								]
							})]
						})]
					}, c.animeId))
				})]
			}),
			added.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimeRow, {
				title: "No catálogo Hikari",
				items: added
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimeRow, {
				title: `Temporada ${data.seasonName} ${data.seasonYear}`,
				href: "/browse/season",
				items: season
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimeRow, {
				title: "Populares",
				href: "/browse/popular",
				items: popular
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimeRow, {
				title: "Mais bem avaliados",
				href: "/browse/top",
				items: top
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimeRow, {
				title: "Em alta",
				href: "/browse/trending",
				items: trending.slice(1)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "pt-4 text-center text-[11px] text-subtle",
				children: ["Fonte: ", data.source === "anilist" ? "AniList" : "MyAnimeList / Jikan"]
			})
		]
	});
}
//#endregion
export { Home as component };
