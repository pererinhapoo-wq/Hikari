import { i as overlaySlim, r as localToAnime } from "./store-Cos-sjSt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/overlay-BP0tE_9a.js
function overlayList(remote, locals) {
	return overlaySlim(remote, locals, (l) => localToAnime(l));
}
function mergeDetail(remote, id, locals) {
	const byId = locals.find((a) => a.id === id);
	if (byId) {
		const local = localToAnime(byId);
		if (!remote) return local;
		return {
			...remote,
			...local,
			titles: local.titles,
			cover: local.cover || remote.cover,
			banner: local.banner || remote.banner,
			synopsis: local.synopsis || remote.synopsis,
			seasons: local.seasons.length ? local.seasons : remote.seasons,
			trailerId: local.trailerId || remote.trailerId,
			genres: local.genres.length ? local.genres : remote.genres,
			recommendations: remote.recommendations,
			streamingEpisodes: remote.streamingEpisodes,
			studios: remote.studios,
			source: "local"
		};
	}
	if (!remote) return null;
	const byAni = remote.anilistId ? locals.find((a) => a.anilistId === remote.anilistId) : void 0;
	if (byAni) {
		const local = localToAnime(byAni);
		return {
			...remote,
			...local,
			id: remote.id,
			seasons: local.seasons.length ? local.seasons : remote.seasons,
			trailerId: local.trailerId || remote.trailerId,
			recommendations: remote.recommendations,
			streamingEpisodes: remote.streamingEpisodes,
			studios: remote.studios
		};
	}
	return remote;
}
//#endregion
export { overlayList as n, mergeDetail as t };
