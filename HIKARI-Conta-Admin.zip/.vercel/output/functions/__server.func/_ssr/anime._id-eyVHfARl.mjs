import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as formatLabel, d as scoreLabel, f as seasonLabel, h as youtubeIdFrom, l as genreLabel, p as statusLabel } from "./labels-C6131ZKr.mjs";
import { a as useHikariStore, n as displayTitle } from "./store-Cos-sjSt.mjs";
import { _ as BookmarkCheck, g as Bookmark, l as Play, u as Pencil } from "../_libs/lucide-react.mjs";
import { i as Route$2, u as AnimeCard } from "./router-2uA790DW.mjs";
import { t as Button } from "./button-BQS8iGY-.mjs";
import { t as mergeDetail } from "./overlay-BP0tE_9a.mjs";
import { t as Badge } from "./badge-DFNkFcMp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/anime._id-eyVHfARl.js
var import_jsx_runtime = require_jsx_runtime();
function AnimePage() {
	const { id } = Route$2.useParams();
	const { remote } = Route$2.useLoaderData();
	const locals = useHikariStore((s) => s.animes);
	const inList = useHikariStore((s) => s.myList.includes(id) || (remote?.id ? s.myList.includes(remote.id) : false));
	const toggleList = useHikariStore((s) => s.toggleList);
	const anime = mergeDetail(remote, id, locals);
	if (!anime) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-24 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl",
			children: "Anime não encontrado"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			className: "mt-3 inline-block text-sm text-muted underline",
			children: "Voltar ao início"
		})]
	});
	const title = displayTitle(anime);
	const yt = youtubeIdFrom(anime.trailerId);
	const localRecord = locals.find((a) => a.id === anime.id || anime.anilistId && a.anilistId === anime.anilistId);
	const seasons = anime.seasons;
	const episodeCount = seasons.reduce((n, s) => n + s.episodes.length, 0) || anime.episodesCount || 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative -mx-4 h-48 overflow-hidden sm:-mx-6 sm:h-72",
				children: [(anime.banner || anime.cover) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: anime.banner || anime.cover,
					alt: "",
					className: "size-full object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-t from-bg via-bg/40 to-transparent" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 -mt-20 flex flex-col gap-5 sm:-mt-24 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto w-32 shrink-0 overflow-hidden rounded-lg bg-elevated shadow-[var(--shadow-border)] sm:mx-0 sm:w-40",
					children: anime.cover ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: anime.cover,
						alt: "",
						className: "aspect-2/3 w-full object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-2/3" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 space-y-3 sm:pt-16",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] tracking-[0.28em] text-muted uppercase",
							children: [formatLabel(anime.format), anime.year ? ` · ${anime.year}` : ""]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-3xl leading-tight tracking-tight sm:text-4xl",
							children: title
						}),
						anime.titles.native && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-sm text-muted",
							children: anime.titles.native
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								anime.score != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium tabular-nums text-score",
									children: scoreLabel(anime.score)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-muted",
									children: statusLabel(anime.status)
								}),
								episodeCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm text-muted",
									children: [episodeCount, " episódios"]
								}),
								seasonLabel(anime.season, anime.year) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-muted",
									children: seasonLabel(anime.season, anime.year)
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-1.5",
							children: anime.genres.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/search",
								search: {
									q: "",
									genre: g,
									year: "",
									format: "",
									status: "",
									sort: "TRENDING_DESC"
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: genreLabel(g) })
							}, g))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2 pt-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/watch/$id",
										params: { id: anime.id },
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), "Assistir"]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									variant: "outline",
									onClick: () => toggleList(anime),
									children: [inList ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4" }), inList ? "Na lista" : "Minha Lista"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									variant: "ghost",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/admin/$id",
										params: { id: localRecord?.id ?? "new" },
										search: { importId: anime.id },
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" }), "Editar"]
									})
								})
							]
						})
					]
				})]
			}),
			anime.synopsis && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8 max-w-3xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-[11px] tracking-[0.28em] text-muted uppercase",
					children: "Sinopse"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: anime.synopsis
				})]
			}),
			yt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-[11px] tracking-[0.28em] text-muted uppercase",
					children: "Trailer"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 aspect-video overflow-hidden rounded-xl bg-elevated shadow-[var(--shadow-border)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
						title: `Trailer de ${title}`,
						src: `https://www.youtube-nocookie.com/embed/${yt}`,
						className: "size-full",
						allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
						allowFullScreen: true
					})
				})]
			}),
			seasons.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl tracking-tight",
					children: "Episódios"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 space-y-8",
					children: seasons.map((season) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [seasons.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mb-3 text-sm font-medium text-muted",
						children: season.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "grid gap-2 sm:grid-cols-2",
						children: season.episodes.map((ep) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/watch/$id",
							params: { id: anime.id },
							search: { ep: ep.id },
							className: "flex gap-3 rounded-lg bg-surface p-2 shadow-[var(--shadow-border)] transition-colors hover:bg-elevated",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-16 w-28 shrink-0 overflow-hidden rounded-md bg-elevated",
								children: ep.thumbnail || anime.cover ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: ep.thumbnail || anime.cover,
									alt: "",
									className: "size-full object-cover"
								}) : null
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 py-0.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[11px] tabular-nums text-subtle",
										children: ["Ep. ", ep.number]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-sm text-fg",
										children: ep.title
									}),
									ep.duration && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-subtle",
										children: ep.duration
									})
								]
							})]
						}) }, ep.id))
					})] }, season.id))
				})]
			}),
			anime.studios.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-8 text-xs text-subtle",
				children: ["Estúdio: ", anime.studios.join(", ")]
			}),
			anime.recommendations.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10 space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl tracking-tight",
					children: "Relacionados"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rail -mx-4 px-4 sm:-mx-6 sm:px-6",
					children: anime.recommendations.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimeCard, { anime: r }, r.id))
				})]
			})
		]
	});
}
//#endregion
export { AnimePage as component };
