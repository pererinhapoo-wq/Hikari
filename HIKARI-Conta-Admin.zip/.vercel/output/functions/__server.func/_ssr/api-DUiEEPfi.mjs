import { f as seasonLabel, h as youtubeIdFrom, m as stripHtml, s as currentAnimeSeason } from "./labels-C6131ZKr.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as string, i as object, r as number, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-DUiEEPfi.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var ANILIST = "https://graphql.anilist.co";
var JIKAN = "https://api.jikan.moe/v4";
var CARD_FIELDS = `
  id
  idMal
  title { romaji english native }
  coverImage { extraLarge large color }
  bannerImage
  averageScore
  genres
  format
  status
  episodes
  season
  seasonYear
  description(asHtml: false)
  trailer { id site thumbnail }
`;
var cache = /* @__PURE__ */ new Map();
var TTL = 3e5;
function fromCache(key) {
	const hit = cache.get(key);
	if (!hit) return null;
	if (Date.now() - hit.at > TTL) {
		cache.delete(key);
		return null;
	}
	return hit.data;
}
function toCache(key, data) {
	cache.set(key, {
		at: Date.now(),
		data
	});
	return data;
}
async function anilistGraphQL(query, variables) {
	const res = await fetch(ANILIST, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Accept: "application/json"
		},
		body: JSON.stringify({
			query,
			variables
		}),
		signal: AbortSignal.timeout(12e3)
	});
	if (!res.ok) throw new Error(`AniList indisponível (${res.status})`);
	const json = await res.json();
	if (json.errors?.length) throw new Error(json.errors[0]?.message ?? "AniList error");
	if (!json.data) throw new Error("AniList sem dados");
	return json.data;
}
async function jikanFetch(path, attempt = 0) {
	const res = await fetch(`${JIKAN}${path}`, {
		headers: {
			Accept: "application/json",
			"User-Agent": "Hikari/1.0 (anime catalog)"
		},
		signal: AbortSignal.timeout(12e3)
	});
	if (res.status === 429 && attempt < 2) {
		await new Promise((r) => setTimeout(r, 900 * (attempt + 1)));
		return jikanFetch(path, attempt + 1);
	}
	if (!res.ok) throw new Error(`MyAnimeList indisponível (${res.status})`);
	return await res.json();
}
function trailerFromAni(media) {
	const t = media.trailer;
	if (!t?.id) return null;
	if ((t.site ?? "youtube").toLowerCase() === "youtube") return t.id;
	return youtubeIdFrom(t.id);
}
function mapAniSlim(media) {
	return {
		id: String(media.id),
		anilistId: media.id,
		malId: media.idMal ?? void 0,
		titles: {
			romaji: media.title?.romaji ?? "",
			english: media.title?.english ?? "",
			native: media.title?.native ?? ""
		},
		cover: media.coverImage?.extraLarge || media.coverImage?.large || "",
		banner: media.bannerImage || "",
		synopsis: stripHtml(media.description),
		score: media.averageScore ?? null,
		genres: media.genres ?? [],
		format: media.format ?? "",
		status: media.status ?? "",
		episodesCount: media.episodes ?? null,
		season: media.season ?? null,
		year: media.seasonYear ?? null,
		trailerId: trailerFromAni(media),
		color: media.coverImage?.color ?? void 0,
		source: "anilist"
	};
}
function jikanStatus(status) {
	const s = (status ?? "").toLowerCase();
	if (s.includes("air")) return "RELEASING";
	if (s.includes("finish") || s.includes("complete")) return "FINISHED";
	if (s.includes("not yet") || s.includes("upcoming")) return "NOT_YET_RELEASED";
	if (s.includes("hiatus")) return "HIATUS";
	return status?.toUpperCase().replace(/\s+/g, "_") ?? "";
}
function jikanFormat(type) {
	const t = (type ?? "").toUpperCase();
	if (t === "TV") return "TV";
	if (t === "MOVIE") return "MOVIE";
	if (t === "OVA") return "OVA";
	if (t === "ONA") return "ONA";
	if (t === "SPECIAL") return "SPECIAL";
	if (t === "MUSIC") return "MUSIC";
	return t;
}
function mapJikanSlim(a) {
	return {
		id: `mal-${a.mal_id}`,
		malId: a.mal_id,
		titles: {
			romaji: a.title ?? "",
			english: a.title_english ?? "",
			native: a.title_japanese ?? ""
		},
		cover: a.images?.jpg?.large_image_url || a.images?.jpg?.image_url || "",
		banner: a.trailer?.images?.maximum_image_url || "",
		synopsis: stripHtml(a.synopsis),
		score: a.score != null ? Math.round(a.score * 10) : null,
		genres: (a.genres ?? []).map((g) => g.name),
		format: jikanFormat(a.type),
		status: jikanStatus(a.status),
		episodesCount: a.episodes ?? null,
		season: a.season ? a.season.toUpperCase() : null,
		year: a.year ?? null,
		trailerId: a.trailer?.youtube_id ?? null,
		source: "jikan"
	};
}
async function jikanEpisodes(malId) {
	const episodes = [];
	let page = 1;
	let hasNext = true;
	while (hasNext && page <= 8) {
		const json = await jikanFetch(`/anime/${malId}/episodes?page=${page}`);
		for (const ep of json.data ?? []) episodes.push({
			id: `mal-ep-${malId}-${ep.mal_id}`,
			number: ep.mal_id,
			title: ep.title || ep.title_japanese || `Episódio ${ep.mal_id}`,
			aired: ep.aired ?? void 0
		});
		hasNext = Boolean(json.pagination?.has_next_page);
		page += 1;
	}
	if (!episodes.length) return [];
	return [{
		id: `mal-s1-${malId}`,
		number: 1,
		title: "Temporada 1",
		episodes
	}];
}
function streamingFromAni(media) {
	return (media.streamingEpisodes ?? []).filter((e) => e.url).map((e) => ({
		title: e.title ?? "Episódio",
		thumbnail: e.thumbnail ?? "",
		url: e.url ?? "",
		site: e.site ?? ""
	}));
}
function mapAniFull(media, seasons) {
	return {
		...mapAniSlim(media),
		duration: media.duration ?? null,
		studios: (media.studios?.nodes ?? []).map((n) => n.name),
		nextEpisode: media.nextAiringEpisode ?? void 0,
		streamingEpisodes: streamingFromAni(media),
		seasons,
		recommendations: (media.recommendations?.nodes ?? []).map((n) => n.mediaRecommendation).filter((m) => Boolean(m?.id)).slice(0, 12).map(mapAniSlim)
	};
}
async function fetchHomeFromAni() {
	const { season, year } = currentAnimeSeason();
	const data = await anilistGraphQL(`
    query Home($season: MediaSeason, $year: Int) {
      trending: Page(page: 1, perPage: 18) {
        media(type: ANIME, sort: TRENDING_DESC) { ${CARD_FIELDS} }
      }
      popular: Page(page: 1, perPage: 18) {
        media(type: ANIME, sort: POPULARITY_DESC) { ${CARD_FIELDS} }
      }
      top: Page(page: 1, perPage: 18) {
        media(type: ANIME, sort: SCORE_DESC) { ${CARD_FIELDS} }
      }
      season: Page(page: 1, perPage: 18) {
        media(type: ANIME, season: $season, seasonYear: $year, sort: POPULARITY_DESC) { ${CARD_FIELDS} }
      }
      genres: GenreCollection
    }
  `, {
		season,
		year
	});
	return {
		trending: (data.trending.media ?? []).map(mapAniSlim),
		popular: (data.popular.media ?? []).map(mapAniSlim),
		top: (data.top.media ?? []).map(mapAniSlim),
		season: (data.season.media ?? []).map(mapAniSlim),
		seasonName: seasonLabel(season),
		seasonYear: year,
		source: "anilist",
		genres: (data.genres ?? []).filter((g) => g && g !== "Hentai")
	};
}
async function fetchHomeFromJikan() {
	const { season, year } = currentAnimeSeason();
	const [now, top, popular] = await Promise.all([
		jikanFetch("/seasons/now?limit=18"),
		jikanFetch("/top/anime?filter=bypopularity&limit=18"),
		jikanFetch("/top/anime?limit=18")
	]);
	const seasonItems = (now.data ?? []).map(mapJikanSlim);
	return {
		trending: seasonItems,
		popular: (top.data ?? []).map(mapJikanSlim),
		top: (popular.data ?? []).map(mapJikanSlim),
		season: seasonItems,
		seasonName: seasonLabel(season),
		seasonYear: year,
		source: "jikan",
		genres: [
			"Action",
			"Adventure",
			"Comedy",
			"Drama",
			"Fantasy",
			"Horror",
			"Mecha",
			"Mystery",
			"Romance",
			"Sci-Fi",
			"Slice of Life",
			"Sports",
			"Supernatural",
			"Thriller"
		]
	};
}
var fetchHomeCatalog_createServerFn_handler = createServerRpc({
	id: "d3b9b89920391ed81aae2521622fa9c80548287d9302fbe6eeae13a8f28bf360",
	name: "fetchHomeCatalog",
	filename: "src/lib/api.ts"
}, (opts) => fetchHomeCatalog.__executeServer(opts));
var fetchHomeCatalog = createServerFn({ method: "GET" }).handler(fetchHomeCatalog_createServerFn_handler, async () => {
	const key = "home";
	const cached = fromCache(key);
	if (cached) return cached;
	try {
		return toCache(key, await fetchHomeFromAni());
	} catch {
		return toCache(key, await fetchHomeFromJikan());
	}
});
var searchSchema = object({
	q: string().optional(),
	genre: string().optional(),
	year: string().optional(),
	format: string().optional(),
	status: string().optional(),
	sort: string().optional(),
	page: number().optional()
});
async function searchAni(params) {
	const page = params.page ?? 1;
	const sort = params.sort || (params.q ? "SEARCH_MATCH" : "TRENDING_DESC");
	const year = params.year ? Number(params.year) : void 0;
	const data = await anilistGraphQL(`
    query Search(
      $page: Int, $search: String, $genre: String, $year: Int,
      $format: MediaFormat, $status: MediaStatus, $sort: [MediaSort]
    ) {
      Page(page: $page, perPage: 24) {
        pageInfo { hasNextPage }
        media(
          type: ANIME
          search: $search
          genre: $genre
          seasonYear: $year
          format: $format
          status: $status
          sort: $sort
        ) { ${CARD_FIELDS} }
      }
    }
  `, {
		page,
		search: params.q || void 0,
		genre: params.genre || void 0,
		year: year && Number.isFinite(year) ? year : void 0,
		format: params.format || void 0,
		status: params.status || void 0,
		sort: [sort]
	});
	return {
		items: (data.Page.media ?? []).map(mapAniSlim),
		page,
		hasNext: Boolean(data.Page.pageInfo?.hasNextPage),
		source: "anilist"
	};
}
async function searchJikan(params) {
	const page = params.page ?? 1;
	const qs = new URLSearchParams();
	if (params.q) qs.set("q", params.q);
	qs.set("page", String(page));
	qs.set("limit", "24");
	qs.set("sfw", "true");
	if (params.genre) qs.set("genres", params.genre);
	const json = await jikanFetch(`/anime?${qs.toString()}`);
	return {
		items: (json.data ?? []).map(mapJikanSlim),
		page,
		hasNext: Boolean(json.pagination?.has_next_page),
		source: "jikan"
	};
}
var searchCatalog_createServerFn_handler = createServerRpc({
	id: "1aba2ecb2c3d3034b6e5626ce7aa323dbe8a6377fd2a3a06673ff30cc0db79c0",
	name: "searchCatalog",
	filename: "src/lib/api.ts"
}, (opts) => searchCatalog.__executeServer(opts));
var searchCatalog = createServerFn({ method: "GET" }).validator(searchSchema).handler(searchCatalog_createServerFn_handler, async ({ data }) => {
	const key = `search:${JSON.stringify(data)}`;
	const cached = fromCache(key);
	if (cached) return cached;
	try {
		return toCache(key, await searchAni(data));
	} catch {
		return toCache(key, await searchJikan(data));
	}
});
var idSchema = object({ id: string() });
var fetchAnimeDetail_createServerFn_handler = createServerRpc({
	id: "360b5d0dac3f25b0b4b525917f3925b73dd02a3596d0c36a27307ec961b976f9",
	name: "fetchAnimeDetail",
	filename: "src/lib/api.ts"
}, (opts) => fetchAnimeDetail.__executeServer(opts));
var fetchAnimeDetail = createServerFn({ method: "GET" }).validator(idSchema).handler(fetchAnimeDetail_createServerFn_handler, async ({ data }) => {
	const { id } = data;
	if (id.startsWith("local-")) return null;
	const key = `detail:${id}`;
	const cached = fromCache(key);
	if (cached) return cached;
	if (id.startsWith("mal-")) {
		const malId = Number(id.replace("mal-", ""));
		const json = await jikanFetch(`/anime/${malId}/full`);
		const slim = mapJikanSlim(json.data);
		let seasons = [];
		try {
			seasons = await jikanEpisodes(malId);
		} catch {
			seasons = [];
		}
		return toCache(key, {
			...slim,
			studios: (json.data.studios ?? []).map((s) => s.name),
			streamingEpisodes: [],
			seasons,
			recommendations: []
		});
	}
	const anilistId = Number(id);
	if (!Number.isFinite(anilistId)) return null;
	try {
		const media = (await anilistGraphQL(`
        query Detail($id: Int) {
          Media(id: $id, type: ANIME) {
            ${CARD_FIELDS}
            duration
            studios(isMain: true) { nodes { name } }
            nextAiringEpisode { episode airingAt }
            streamingEpisodes { title thumbnail url site }
            recommendations(sort: RATING_DESC, perPage: 10) {
              nodes {
                mediaRecommendation {
                  id
                  idMal
                  title { romaji english native }
                  coverImage { extraLarge large color }
                  bannerImage
                  averageScore
                  genres
                  format
                  status
                  episodes
                  season
                  seasonYear
                  trailer { id site }
                }
              }
            }
          }
        }
      `, { id: anilistId })).Media;
		if (!media) return null;
		let seasons = [];
		if (media.idMal) try {
			seasons = await jikanEpisodes(media.idMal);
		} catch {
			seasons = [];
		}
		if (!seasons.length && (media.streamingEpisodes?.length || media.episodes)) {
			const fromStream = (media.streamingEpisodes ?? []).map((e, i) => ({
				id: `stream-${media.id}-${i}`,
				number: i + 1,
				title: e.title ?? `Episódio ${i + 1}`,
				thumbnail: e.thumbnail,
				videoUrl: e.url
			}));
			const count = media.episodes ?? fromStream.length;
			const episodes = fromStream.length >= count ? fromStream : Array.from({ length: count }, (_, i) => {
				return fromStream[i] ?? {
					id: `ep-${media.id}-${i + 1}`,
					number: i + 1,
					title: `Episódio ${i + 1}`
				};
			});
			seasons = [{
				id: `s1-${media.id}`,
				number: 1,
				title: "Temporada 1",
				episodes
			}];
		}
		return toCache(key, mapAniFull(media, seasons));
	} catch {
		try {
			const json = await jikanFetch(`/anime/${anilistId}/full`);
			const slim = mapJikanSlim(json.data);
			let seasons = [];
			try {
				seasons = await jikanEpisodes(anilistId);
			} catch {
				seasons = [];
			}
			return toCache(key, {
				...slim,
				studios: (json.data.studios ?? []).map((s) => s.name),
				streamingEpisodes: [],
				seasons,
				recommendations: []
			});
		} catch {
			return null;
		}
	}
});
var browseSchema = object({
	section: _enum([
		"popular",
		"season",
		"top",
		"trending"
	]),
	page: number().optional()
});
var fetchBrowse_createServerFn_handler = createServerRpc({
	id: "e33500c3c281a5f6a547ed12cbad641f00fef7783a8c9729d18cdbf27e717ed4",
	name: "fetchBrowse",
	filename: "src/lib/api.ts"
}, (opts) => fetchBrowse.__executeServer(opts));
var fetchBrowse = createServerFn({ method: "GET" }).validator(browseSchema).handler(fetchBrowse_createServerFn_handler, async ({ data }) => {
	const page = data.page ?? 1;
	const key = `browse:${data.section}:${page}`;
	const cached = fromCache(key);
	if (cached) return cached;
	const { season, year } = currentAnimeSeason();
	const sortMap = {
		popular: "POPULARITY_DESC",
		top: "SCORE_DESC",
		trending: "TRENDING_DESC",
		season: "POPULARITY_DESC"
	};
	try {
		const isSeason = data.section === "season";
		const result = await anilistGraphQL(isSeason ? `
        query BrowseSeason($page: Int, $sort: [MediaSort], $season: MediaSeason, $year: Int) {
          Page(page: $page, perPage: 24) {
            pageInfo { hasNextPage }
            media(type: ANIME, sort: $sort, season: $season, seasonYear: $year) { ${CARD_FIELDS} }
          }
        }
      ` : `
        query Browse($page: Int, $sort: [MediaSort]) {
          Page(page: $page, perPage: 24) {
            pageInfo { hasNextPage }
            media(type: ANIME, sort: $sort) { ${CARD_FIELDS} }
          }
        }
      `, isSeason ? {
			page,
			sort: [sortMap.season],
			season,
			year
		} : {
			page,
			sort: [sortMap[data.section]]
		});
		return toCache(key, {
			items: (result.Page.media ?? []).map(mapAniSlim),
			page,
			hasNext: Boolean(result.Page.pageInfo?.hasNextPage),
			source: "anilist"
		});
	} catch {
		const json = await jikanFetch(data.section === "top" ? `/top/anime?page=${page}&limit=24` : data.section === "popular" ? `/top/anime?filter=bypopularity&page=${page}&limit=24` : `/seasons/now?page=${page}&limit=24`);
		return toCache(key, {
			items: (json.data ?? []).map(mapJikanSlim),
			page,
			hasNext: Boolean(json.pagination?.has_next_page),
			source: "jikan"
		});
	}
});
//#endregion
export { fetchAnimeDetail_createServerFn_handler, fetchBrowse_createServerFn_handler, fetchHomeCatalog_createServerFn_handler, searchCatalog_createServerFn_handler };
