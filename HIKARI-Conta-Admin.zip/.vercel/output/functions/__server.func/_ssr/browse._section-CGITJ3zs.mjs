import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as useHikariStore } from "./store-Cos-sjSt.mjs";
import { r as Route$1, u as AnimeCard } from "./router-2uA790DW.mjs";
import { n as overlayList } from "./overlay-BP0tE_9a.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/browse._section-CGITJ3zs.js
var import_jsx_runtime = require_jsx_runtime();
var TITLES = {
	popular: "Populares",
	season: "Temporada atual",
	top: "Mais bem avaliados",
	trending: "Em alta"
};
function BrowsePage() {
	const { result, section } = Route$1.useLoaderData();
	const locals = useHikariStore((s) => s.animes);
	const items = overlayList(result.items, locals);
	const title = TITLES[section] ?? "Catálogo";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 pt-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] tracking-[0.28em] text-muted uppercase",
			children: "Explorar"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl tracking-tight",
			children: title
		})] }), items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "py-16 text-center text-muted",
			children: [
				"Nada por aqui.",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "text-fg underline",
					children: "Voltar"
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-6",
			children: items.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimeCard, { anime: a }, a.id))
		})]
	});
}
//#endregion
export { BrowsePage as component };
