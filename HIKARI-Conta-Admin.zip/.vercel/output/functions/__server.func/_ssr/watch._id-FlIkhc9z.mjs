import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { h as youtubeIdFrom, o as cn, u as isDirectVideo } from "./labels-C6131ZKr.mjs";
import { a as useHikariStore, n as displayTitle } from "./store-Cos-sjSt.mjs";
import { h as ChevronLeft, m as ChevronRight, t as X } from "../_libs/lucide-react.mjs";
import { n as Route } from "./router-2uA790DW.mjs";
import { t as Button } from "./button-BQS8iGY-.mjs";
import { t as mergeDetail } from "./overlay-BP0tE_9a.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/watch._id-FlIkhc9z.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function WatchPage() {
	const { id } = Route.useParams();
	const { ep: epQuery } = Route.useSearch();
	const { remote } = Route.useLoaderData();
	const locals = useHikariStore((s) => s.animes);
	const markContinue = useHikariStore((s) => s.markContinue);
	const anime = mergeDetail(remote, id, locals);
	const episodes = (0, import_react.useMemo)(() => {
		if (!anime) return [];
		return anime.seasons.flatMap((s) => s.episodes);
	}, [anime]);
	const current = (0, import_react.useMemo)(() => {
		if (!episodes.length) return null;
		return episodes.find((e) => e.id === epQuery) ?? episodes[0];
	}, [episodes, epQuery]);
	const idx = current ? episodes.findIndex((e) => e.id === current.id) : -1;
	const prev = idx > 0 ? episodes[idx - 1] : null;
	const next = idx >= 0 && idx < episodes.length - 1 ? episodes[idx + 1] : null;
	(0, import_react.useEffect)(() => {
		if (!anime || !current) return;
		markContinue({
			animeId: anime.id,
			episodeId: current.id,
			episodeNumber: current.number,
			episodeTitle: current.title,
			cover: current.thumbnail || anime.cover,
			title: displayTitle(anime),
			updatedAt: Date.now()
		});
	}, [
		anime,
		current,
		markContinue
	]);
	if (!anime) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh items-center justify-center bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Título não encontrado." })
	});
	const title = displayTitle(anime);
	const playUrl = current?.videoUrl;
	const yt = youtubeIdFrom(playUrl) || (!playUrl ? youtubeIdFrom(anime.trailerId) : null);
	const file = playUrl && isDirectVideo(playUrl) ? playUrl : null;
	const external = playUrl && !yt && !file ? playUrl : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex h-14 items-center gap-2 px-3 sm:px-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/anime/$id",
				params: { id: anime.id },
				className: "flex size-11 items-center justify-center rounded-md text-muted hover:bg-elevated hover:text-fg",
				"aria-label": "Fechar player",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-sm font-medium",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-xs text-muted",
					children: current ? `Episódio ${current.number} · ${current.title}` : "Trailer"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-6xl flex-1 px-3 pb-6 sm:px-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "aspect-video overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]",
					children: yt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
						title: `${title} — player`,
						src: `https://www.youtube-nocookie.com/embed/${yt}?autoplay=1&rel=0`,
						className: "size-full",
						allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
						allowFullScreen: true
					}) : file ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						src: file,
						controls: true,
						autoPlay: true,
						className: "size-full bg-bg object-contain"
					}) : external ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex size-full flex-col items-center justify-center gap-3 px-6 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl",
								children: "Este episódio abre no site oficial"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "max-w-md text-sm text-muted",
								children: "O catálogo não replica streams protegidos. Use o link da fonte ou adicione uma URL de vídeo no painel admin."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: external,
									target: "_blank",
									rel: "noreferrer",
									children: "Abrir episódio"
								})
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex size-full flex-col items-center justify-center gap-3 px-6 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl",
								children: "Sem vídeo neste episódio"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "max-w-md text-sm text-muted",
								children: "Adicione um trailer do YouTube ou uma URL de vídeo no Admin para reproduzir aqui."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "outline",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/admin/$id",
									params: { id: anime.id.startsWith("local-") ? anime.id : "new" },
									search: { importId: anime.id },
									children: "Abrir Admin"
								})
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-center justify-between gap-3",
					children: [prev ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						size: "sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/watch/$id",
							params: { id: anime.id },
							search: { ep: prev.id },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" }), "Anterior"]
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), next && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/watch/$id",
							params: { id: anime.id },
							search: { ep: next.id },
							children: ["Próximo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })]
						})
					})]
				}),
				episodes.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-6 grid max-h-[40vh] gap-1 overflow-y-auto sm:grid-cols-2",
					children: episodes.map((ep) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/watch/$id",
						params: { id: anime.id },
						search: { ep: ep.id },
						className: cn("flex min-h-12 items-center gap-3 rounded-md px-3 text-sm", current?.id === ep.id ? "bg-elevated text-fg" : "text-muted hover:bg-surface hover:text-fg"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-8 tabular-nums text-xs text-subtle",
							children: ep.number
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: ep.title
						})]
					}) }, ep.id))
				})
			]
		})]
	});
}
//#endregion
export { WatchPage as component };
