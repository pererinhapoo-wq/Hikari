import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { o as cn } from "./labels-C6131ZKr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/native-select-Dyxlfy64.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Label = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
	ref,
	className: cn("text-xs font-medium tracking-wide text-muted", className),
	...props
}));
Label.displayName = "Label";
var NativeSelect = (0, import_react.forwardRef)(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
	ref,
	className: cn("h-11 w-full appearance-none rounded-md bg-elevated bg-[length:12px] bg-[right_0.75rem_center] bg-no-repeat px-3 pr-9 text-sm text-fg shadow-[var(--shadow-border)]", "bg-[url('data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%2212%22 height=%2212%22 fill=%22none%22 stroke=%22%239a9a96%22 stroke-width=%221.6%22><path d=%22M3 4.5 6 8l3-3.5%22/></svg>')]", "focus:outline-none focus:shadow-[var(--shadow-border-hover)]", className),
	...props,
	children
}));
NativeSelect.displayName = "NativeSelect";
//#endregion
export { NativeSelect as n, Label as t };
