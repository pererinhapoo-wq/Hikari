import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as STATUS_PT, h as youtubeIdFrom, o as cn, r as SEASON_PT, t as FORMAT_PT } from "./labels-C6131ZKr.mjs";
import { a as useHikariStore, t as animeToLocal } from "./store-Cos-sjSt.mjs";
import { c as Plus, i as Trash2 } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as Route$3 } from "./router-2uA790DW.mjs";
import { t as Button } from "./button-BQS8iGY-.mjs";
import { t as Input } from "./input-DuHEPNHM.mjs";
import { n as NativeSelect, t as Label } from "./native-select-Dyxlfy64.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin._id-wgF3kPBt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Textarea = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
	ref,
	className: cn("min-h-28 w-full rounded-lg bg-elevated px-3 py-2.5 text-sm text-fg shadow-[var(--shadow-border)] placeholder:text-subtle", "transition-[box-shadow] duration-150 focus:outline-none focus:shadow-[var(--shadow-border-hover)]", className),
	...props
}));
Textarea.displayName = "Textarea";
function emptyLocal() {
	const now = Date.now();
	return {
		id: `local-${crypto.randomUUID()}`,
		titleRomaji: "",
		titleEnglish: "",
		titleNative: "",
		cover: "",
		banner: "",
		synopsis: "",
		score: null,
		genres: [],
		format: "TV",
		status: "FINISHED",
		episodesCount: null,
		season: null,
		year: (/* @__PURE__ */ new Date()).getFullYear(),
		trailerId: null,
		hidden: false,
		seasons: [{
			id: `s-${crypto.randomUUID()}`,
			number: 1,
			title: "Temporada 1",
			episodes: []
		}],
		createdAt: now,
		updatedAt: now
	};
}
function AdminEditor() {
	const { id } = Route$3.useParams();
	const { importId } = Route$3.useSearch();
	const { remote } = Route$3.useLoaderData();
	const navigate = useNavigate();
	const stored = useHikariStore((s) => s.animes);
	const hydrated = useHikariStore((s) => s.hydrated);
	const upsertAnime = useHikariStore((s) => s.upsertAnime);
	const removeAnime = useHikariStore((s) => s.removeAnime);
	const [form, setForm] = (0, import_react.useState)(null);
	const [genreText, setGenreText] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		const locals = useHikariStore.getState().animes;
		const next = (locals.find((a) => a.id === id) || (remote?.anilistId ? locals.find((a) => a.anilistId === remote.anilistId) : void 0)) ?? (remote ? animeToLocal(remote) : emptyLocal());
		setForm(next);
		setGenreText(next.genres.join(", "));
	}, [
		hydrated,
		id,
		remote
	]);
	if (!form) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-64 animate-pulse rounded-xl bg-elevated" });
	function set(key, value) {
		setForm((f) => f ? {
			...f,
			[key]: value
		} : f);
	}
	function save() {
		const genres = genreText.split(",").map((g) => g.trim()).filter(Boolean);
		const next = {
			...form,
			genres,
			trailerId: youtubeIdFrom(form.trailerId) ?? (form.trailerId || null),
			updatedAt: Date.now()
		};
		if (!next.titleRomaji && !next.titleEnglish && !next.titleNative) {
			toast.error("Dê um título ao anime.");
			return;
		}
		upsertAnime(next);
		toast.success("Salvo neste dispositivo.");
		navigate({
			to: "/admin/$id",
			params: { id: next.id }
		});
	}
	function addSeason() {
		const n = form.seasons.length + 1;
		setForm((f) => f ? {
			...f,
			seasons: [...f.seasons, {
				id: `s-${crypto.randomUUID()}`,
				number: n,
				title: `Temporada ${n}`,
				episodes: []
			}]
		} : f);
	}
	function patchSeason(sid, patch) {
		setForm((f) => f ? {
			...f,
			seasons: f.seasons.map((s) => s.id === sid ? {
				...s,
				...patch
			} : s)
		} : f);
	}
	function removeSeason(sid) {
		setForm((f) => f ? {
			...f,
			seasons: f.seasons.filter((s) => s.id !== sid)
		} : f);
	}
	function addEpisode(sid) {
		setForm((f) => f ? {
			...f,
			seasons: f.seasons.map((s) => {
				if (s.id !== sid) return s;
				const number = (s.episodes.at(-1)?.number ?? 0) + 1;
				const ep = {
					id: `e-${crypto.randomUUID()}`,
					number,
					title: `Episódio ${number}`
				};
				return {
					...s,
					episodes: [...s.episodes, ep]
				};
			})
		} : f);
	}
	function patchEpisode(sid, eid, patch) {
		setForm((f) => f ? {
			...f,
			seasons: f.seasons.map((s) => s.id === sid ? {
				...s,
				episodes: s.episodes.map((e) => e.id === eid ? {
					...e,
					...patch
				} : e)
			} : s)
		} : f);
	}
	function removeEpisode(sid, eid) {
		setForm((f) => f ? {
			...f,
			seasons: f.seasons.map((s) => s.id === sid ? {
				...s,
				episodes: s.episodes.filter((e) => e.id !== eid)
			} : s)
		} : f);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8 pt-6 pb-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/admin",
					className: "text-xs text-muted hover:text-fg",
					children: "← Painel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-3xl tracking-tight",
					children: id === "new" && !importId ? "Novo anime" : "Editar anime"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [id !== "new" && stored.some((a) => a.id === form.id) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						onClick: () => {
							removeAnime(form.id);
							toast.success("Excluído.");
							navigate({ to: "/admin" });
						},
						children: "Excluir"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						onClick: save,
						children: "Salvar"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 lg:grid-cols-[12rem_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden rounded-lg bg-elevated shadow-[var(--shadow-border)]",
						children: form.cover ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: form.cover,
							alt: "",
							className: "aspect-2/3 w-full object-cover"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex aspect-2/3 items-center justify-center text-xs text-subtle",
							children: "Sem capa"
						})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Título (romaji)",
							className: "sm:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: form.titleRomaji,
								onChange: (e) => set("titleRomaji", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Título em inglês",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: form.titleEnglish,
								onChange: (e) => set("titleEnglish", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Título original",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: form.titleNative,
								onChange: (e) => set("titleNative", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "URL da capa",
							className: "sm:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: form.cover,
								onChange: (e) => set("cover", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "URL do banner",
							className: "sm:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: form.banner,
								onChange: (e) => set("banner", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Sinopse",
							className: "sm:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: form.synopsis,
								onChange: (e) => set("synopsis", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Gêneros (vírgula)",
							className: "sm:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: genreText,
								onChange: (e) => setGenreText(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Nota (0–100)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: 0,
								max: 100,
								value: form.score ?? "",
								onChange: (e) => set("score", e.target.value === "" ? null : Number(e.target.value))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Ano",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: form.year ?? "",
								onChange: (e) => set("year", e.target.value === "" ? null : Number(e.target.value))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Formato",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
								value: form.format,
								onChange: (e) => set("format", e.target.value),
								children: Object.entries(FORMAT_PT).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: k,
									children: v
								}, k))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Status",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
								value: form.status,
								onChange: (e) => set("status", e.target.value),
								children: Object.entries(STATUS_PT).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: k,
									children: v
								}, k))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Temporada",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
								value: form.season ?? "",
								onChange: (e) => set("season", e.target.value || null),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "—"
								}), Object.entries(SEASON_PT).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: k,
									children: v
								}, k))]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Trailer (YouTube URL ou ID)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: form.trailerId ?? "",
								onChange: (e) => set("trailerId", e.target.value || null)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex h-11 items-center gap-2 text-sm text-muted sm:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: form.hidden,
								onChange: (e) => set("hidden", e.target.checked),
								className: "size-4 accent-primary"
							}), "Ocultar do catálogo público"]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Temporadas e episódios"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "outline",
						size: "sm",
						onClick: addSeason,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Temporada"]
					})]
				}), form.seasons.map((season) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-3 sm:flex-row",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Nome",
									className: "flex-1",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: season.title,
										onChange: (e) => patchSeason(season.id, { title: e.target.value })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Nº",
									className: "w-24",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										value: season.number,
										onChange: (e) => patchSeason(season.id, { number: Number(e.target.value) })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "ghost",
									size: "icon",
									className: "self-end",
									"aria-label": "Remover temporada",
									onClick: () => removeSeason(season.id),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 text-danger" })
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 space-y-3",
							children: season.episodes.map((ep) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "rounded-lg bg-elevated p-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-2 sm:grid-cols-12",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "#",
											className: "sm:col-span-1",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "number",
												value: ep.number,
												onChange: (e) => patchEpisode(season.id, ep.id, { number: Number(e.target.value) })
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Título",
											className: "sm:col-span-5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: ep.title,
												onChange: (e) => patchEpisode(season.id, ep.id, { title: e.target.value })
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Duração",
											className: "sm:col-span-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: ep.duration ?? "",
												onChange: (e) => patchEpisode(season.id, ep.id, { duration: e.target.value }),
												placeholder: "24 min"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "URL do vídeo",
											className: "sm:col-span-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: ep.videoUrl ?? "",
												onChange: (e) => patchEpisode(season.id, ep.id, { videoUrl: e.target.value }),
												placeholder: "YouTube ou .mp4"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Thumb",
											className: "sm:col-span-11",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: ep.thumbnail ?? "",
												onChange: (e) => patchEpisode(season.id, ep.id, { thumbnail: e.target.value })
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											variant: "ghost",
											size: "icon",
											className: "sm:col-span-1 sm:self-end",
											"aria-label": "Remover episódio",
											onClick: () => removeEpisode(season.id, ep.id),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 text-danger" })
										})
									]
								})
							}, ep.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "outline",
							size: "sm",
							className: "mt-3",
							onClick: () => addEpisode(season.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Episódio"]
						})
					]
				}, season.id))]
			})
		]
	});
}
function Field({ label, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
			className: "mb-1.5 block",
			children: label
		}), children]
	});
}
//#endregion
export { AdminEditor as component };
