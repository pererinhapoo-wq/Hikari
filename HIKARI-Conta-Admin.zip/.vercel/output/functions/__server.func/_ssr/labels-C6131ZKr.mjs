import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/labels-C6131ZKr.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function stripHtml(input) {
	if (!input) return "";
	return input.replace(/<br\s*\/?>/gi, "\n").replace(/<\/p>/gi, "\n").replace(/<[^>]+>/g, "").replace(/&/g, "&").replace(/"/g, "\"").replace(/&#039;/g, "'").replace(/</g, "<").replace(/>/g, ">").replace(/\n{3,}/g, "\n\n").trim();
}
function youtubeIdFrom(input) {
	if (!input) return null;
	const trimmed = input.trim();
	if (/^[\w-]{11}$/.test(trimmed)) return trimmed;
	try {
		const url = new URL(trimmed);
		if (url.hostname.includes("youtu.be")) {
			const id = url.pathname.split("/").filter(Boolean)[0];
			return id && id.length === 11 ? id : null;
		}
		const v = url.searchParams.get("v");
		if (v && v.length === 11) return v;
		const embed = url.pathname.match(/\/embed\/([\w-]{11})/);
		if (embed?.[1]) return embed[1];
	} catch {
		return null;
	}
	return null;
}
function isDirectVideo(url) {
	return /\.(mp4|webm|ogg|mov)(\?|$)/i.test(url);
}
function currentAnimeSeason(now = /* @__PURE__ */ new Date()) {
	const month = now.getMonth();
	const year = now.getFullYear();
	if (month <= 2) return {
		season: "WINTER",
		year
	};
	if (month <= 5) return {
		season: "SPRING",
		year
	};
	if (month <= 8) return {
		season: "SUMMER",
		year
	};
	return {
		season: "FALL",
		year
	};
}
var GENRE_PT = {
	Action: "Ação",
	Adventure: "Aventura",
	Comedy: "Comédia",
	Drama: "Drama",
	Ecchi: "Ecchi",
	Fantasy: "Fantasia",
	Horror: "Terror",
	MahouShoujo: "Mahou Shoujo",
	"Mahou Shoujo": "Mahou Shoujo",
	Mecha: "Mecha",
	Music: "Música",
	Mystery: "Mistério",
	Psychological: "Psicológico",
	Romance: "Romance",
	"Sci-Fi": "Ficção científica",
	"Slice of Life": "Slice of Life",
	Sports: "Esportes",
	Supernatural: "Sobrenatural",
	Thriller: "Suspense",
	Hentai: "Hentai"
};
var FORMAT_PT = {
	TV: "Série",
	TV_SHORT: "TV Short",
	MOVIE: "Filme",
	SPECIAL: "Especial",
	OVA: "OVA",
	ONA: "ONA",
	MUSIC: "Música",
	MANGA: "Mangá",
	NOVEL: "Light novel",
	ONE_SHOT: "One-shot"
};
var STATUS_PT = {
	FINISHED: "Encerrado",
	RELEASING: "Em exibição",
	NOT_YET_RELEASED: "Em breve",
	CANCELLED: "Cancelado",
	HIATUS: "Hiato"
};
var SEASON_PT = {
	WINTER: "Inverno",
	SPRING: "Primavera",
	SUMMER: "Verão",
	FALL: "Outono"
};
var SORT_OPTIONS = [
	{
		value: "TRENDING_DESC",
		label: "Em alta"
	},
	{
		value: "POPULARITY_DESC",
		label: "Popularidade"
	},
	{
		value: "SCORE_DESC",
		label: "Nota"
	},
	{
		value: "START_DATE_DESC",
		label: "Mais recentes"
	},
	{
		value: "TITLE_ROMAJI",
		label: "Título A–Z"
	}
];
function genreLabel(genre) {
	return GENRE_PT[genre] ?? genre;
}
function formatLabel(format) {
	if (!format) return "";
	return FORMAT_PT[format] ?? format;
}
function statusLabel(status) {
	if (!status) return "";
	return STATUS_PT[status] ?? status;
}
function seasonLabel(season, year) {
	if (!season) return year ? String(year) : "";
	const s = SEASON_PT[season] ?? season;
	return year ? `${s} ${year}` : s;
}
function scoreLabel(score) {
	if (score == null || Number.isNaN(score)) return "—";
	return (score / 10).toFixed(1);
}
//#endregion
export { STATUS_PT as a, formatLabel as c, scoreLabel as d, seasonLabel as f, youtubeIdFrom as h, SORT_OPTIONS as i, genreLabel as l, stripHtml as m, GENRE_PT as n, cn as o, statusLabel as p, SEASON_PT as r, currentAnimeSeason as s, FORMAT_PT as t, isDirectVideo as u };
