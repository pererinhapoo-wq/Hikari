import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as useHikariStore, r as localToAnime } from "./store-Cos-sjSt.mjs";
import { g as Bookmark } from "../_libs/lucide-react.mjs";
import { u as AnimeCard } from "./router-2uA790DW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/my-list-C_eOQlzc.js
var import_jsx_runtime = require_jsx_runtime();
function MyListPage() {
	const myList = useHikariStore((s) => s.myList);
	const snapshots = useHikariStore((s) => s.snapshots);
	const animes = useHikariStore((s) => s.animes);
	const hydrated = useHikariStore((s) => s.hydrated);
	const items = myList.map((id) => {
		if (snapshots[id]) return snapshots[id];
		const local = animes.find((a) => a.id === id);
		return local ? localToAnime(local) : null;
	}).filter((a) => Boolean(a));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 pt-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] tracking-[0.28em] text-muted uppercase",
			children: "Salvos neste dispositivo"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl tracking-tight",
			children: "Minha Lista"
		})] }), !hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-6",
			children: Array.from({ length: 6 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-2/3 animate-pulse rounded-lg bg-elevated" }, i))
		}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center py-20 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-8 text-subtle" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 font-display text-2xl",
					children: "Sua lista está vazia"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-sm text-sm text-muted",
					children: "Toque no marcador de qualquer capa para guardar títulos e continuar depois."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/search",
					className: "mt-6 text-sm text-fg underline",
					children: "Explorar o catálogo"
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-6",
			children: items.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimeCard, { anime: a }, a.id))
		})]
	});
}
//#endregion
export { MyListPage as component };
