import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { o as cn } from "./labels-C6131ZKr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-DFNkFcMp.js
var import_jsx_runtime = require_jsx_runtime();
function Badge({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex h-7 items-center rounded-full bg-elevated px-2.5 text-xs font-medium text-muted", className),
		...props
	});
}
//#endregion
export { Badge as t };
