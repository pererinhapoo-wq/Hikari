import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as STATUS_PT, i as SORT_OPTIONS, n as GENRE_PT, t as FORMAT_PT } from "./labels-C6131ZKr.mjs";
import { a as useHikariStore } from "./store-Cos-sjSt.mjs";
import { a as SlidersHorizontal, s as Search } from "../_libs/lucide-react.mjs";
import { o as Route$5, u as AnimeCard } from "./router-2uA790DW.mjs";
import { t as Button } from "./button-BQS8iGY-.mjs";
import { t as Input } from "./input-DuHEPNHM.mjs";
import { n as NativeSelect, t as Label } from "./native-select-Dyxlfy64.mjs";
import { n as overlayList } from "./overlay-BP0tE_9a.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/search-I0L7v_9e.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var YEARS = Array.from({ length: 37 }, (_, i) => String(2026 - i));
function SearchPage() {
	const search = Route$5.useSearch();
	const navigate = Route$5.useNavigate();
	const { result, genres } = Route$5.useLoaderData();
	const locals = useHikariStore((s) => s.animes);
	const [draft, setDraft] = (0, import_react.useState)(search.q);
	const [filtersOpen, setFiltersOpen] = (0, import_react.useState)(false);
	const items = (0, import_react.useMemo)(() => {
		const q = search.q.trim().toLowerCase();
		const localHits = overlayList([], locals).filter((a) => {
			if (q && !`${a.titles.romaji} ${a.titles.english} ${a.titles.native}`.toLowerCase().includes(q)) return false;
			if (search.genre && !a.genres.includes(search.genre)) return false;
			return true;
		});
		const remote = overlayList(result.items, locals);
		const seen = new Set(localHits.map((a) => a.id));
		return [...localHits, ...remote.filter((a) => !seen.has(a.id))];
	}, [
		result.items,
		locals,
		search.q,
		search.genre
	]);
	function apply(next) {
		navigate({ search: {
			...search,
			...next
		} });
	}
	const genreOptions = genres.length ? genres : Object.keys(GENRE_PT);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 pt-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] tracking-[0.28em] text-muted uppercase",
					children: "Catálogo"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl tracking-tight",
					children: "Buscar"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2",
				onSubmit: (e) => {
					e.preventDefault();
					apply({ q: draft });
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft,
							onChange: (e) => setDraft(e.target.value),
							placeholder: "Título, estúdio, personagem…",
							className: "pl-10",
							"aria-label": "Buscar animes"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Buscar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						size: "icon",
						"aria-label": "Filtros",
						onClick: () => setFiltersOpen((v) => !v),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "size-4" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: filtersOpen ? "grid gap-3 sm:grid-cols-2 lg:grid-cols-4" : "hidden lg:grid lg:grid-cols-4 lg:gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Gênero",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
							value: search.genre,
							onChange: (e) => apply({ genre: e.target.value }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Todos"
							}), genreOptions.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: g,
								children: GENRE_PT[g] ?? g
							}, g))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Ano",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
							value: search.year,
							onChange: (e) => apply({ year: e.target.value }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Qualquer"
							}), YEARS.map((y) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: y,
								children: y
							}, y))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Formato",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
							value: search.format,
							onChange: (e) => apply({ format: e.target.value }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Todos"
							}), Object.entries(FORMAT_PT).filter(([k]) => [
								"TV",
								"MOVIE",
								"OVA",
								"ONA",
								"SPECIAL",
								"TV_SHORT"
							].includes(k)).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: k,
								children: v
							}, k))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Status",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
							value: search.status,
							onChange: (e) => apply({ status: e.target.value }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Todos"
							}), Object.entries(STATUS_PT).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: k,
								children: v
							}, k))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Ordenar",
						className: "lg:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
							value: search.sort,
							onChange: (e) => apply({ sort: e.target.value }),
							children: SORT_OPTIONS.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: o.value,
								children: o.label
							}, o.value))
						})
					})
				]
			}),
			items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "py-20 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl",
						children: "Nada encontrado"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Tente outro título ou limpe os filtros."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/search",
						search: {
							q: "",
							genre: "",
							year: "",
							format: "",
							status: "",
							sort: "TRENDING_DESC"
						},
						className: "mt-4 inline-block text-sm text-fg underline",
						children: "Limpar busca"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-6",
				children: items.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimeCard, { anime: a }, a.id))
			})
		]
	});
}
function Field({ label, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
			className: "mb-1.5 block",
			children: label
		}), children]
	});
}
//#endregion
export { SearchPage as component };
