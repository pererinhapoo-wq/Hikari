import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as createRootRoute, b as useRouter, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as scoreLabel, o as cn } from "./labels-C6131ZKr.mjs";
import { a as useHikariStore, n as displayTitle } from "./store-Cos-sjSt.mjs";
import { _ as BookmarkCheck, d as House, g as Bookmark, o as Settings2, p as Clapperboard, r as TriangleAlert, s as Search } from "../_libs/lucide-react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as string, i as object, n as literal, o as union, r as number, t as _enum } from "../_libs/zod.mjs";
import { t as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/anime-card-BXqxkHgJ.js
var import_jsx_runtime = require_jsx_runtime();
function AnimeCard({ anime, size = "md" }) {
	const inList = useHikariStore((s) => s.myList.includes(anime.id));
	const toggleList = useHikariStore((s) => s.toggleList);
	const title = displayTitle(anime);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("group relative", size === "sm" ? "w-28" : size === "lg" ? "w-40 sm:w-44" : "w-32 sm:w-36"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/anime/$id",
			params: { id: anime.id },
			className: "block overflow-hidden rounded-lg bg-elevated shadow-[var(--shadow-border)] transition-[transform,box-shadow] duration-200 ease-[var(--ease-out)] hover:-translate-y-0.5 hover:shadow-[var(--shadow-border-hover)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative aspect-2/3 overflow-hidden bg-surface",
				children: [anime.cover ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: anime.cover,
					alt: "",
					className: "size-full object-cover transition-transform duration-500 ease-[var(--ease-out)] group-hover:scale-[1.03]",
					loading: "lazy"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex size-full items-center justify-center px-2 text-center font-display text-lg text-subtle",
					children: title.slice(0, 1)
				}), anime.score != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute top-2 left-2 rounded-sm bg-bg/80 px-1.5 py-0.5 font-medium text-xs tabular-nums text-score backdrop-blur-sm",
					children: scoreLabel(anime.score)
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-2 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "line-clamp-2 text-sm leading-snug text-fg",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-0.5 truncate text-[11px] text-subtle",
					children: [
						anime.year ?? "",
						anime.year && anime.format ? " · " : "",
						anime.format === "TV" ? "Série" : anime.format === "MOVIE" ? "Filme" : ""
					]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": inList ? "Remover da Minha Lista" : "Adicionar à Minha Lista",
			onClick: (e) => {
				e.preventDefault();
				e.stopPropagation();
				toggleList(anime);
			},
			className: "absolute top-2 right-2 flex size-9 items-center justify-center rounded-md bg-bg/70 text-fg opacity-100 backdrop-blur-sm transition-opacity sm:opacity-0 sm:group-hover:opacity-100",
			children: inList ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4" })
		})]
	});
}
function AnimeCardSkeleton({ size = "md" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn(size === "sm" ? "w-28" : size === "lg" ? "w-40 sm:w-44" : "w-32 sm:w-36", "shrink-0"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-2/3 animate-pulse rounded-lg bg-elevated" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-2 h-3 w-4/5 animate-pulse rounded bg-elevated" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-1.5 h-2.5 w-1/2 animate-pulse rounded bg-elevated" })
		]
	});
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/api-upQw_CsW.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var fetchHomeCatalog = createServerFn({ method: "GET" }).handler(createSsrRpc("d3b9b89920391ed81aae2521622fa9c80548287d9302fbe6eeae13a8f28bf360"));
var searchSchema = object({
	q: string().optional(),
	genre: string().optional(),
	year: string().optional(),
	format: string().optional(),
	status: string().optional(),
	sort: string().optional(),
	page: number().optional()
});
var searchCatalog = createServerFn({ method: "GET" }).validator(searchSchema).handler(createSsrRpc("1aba2ecb2c3d3034b6e5626ce7aa323dbe8a6377fd2a3a06673ff30cc0db79c0"));
var idSchema = object({ id: string() });
var fetchAnimeDetail = createServerFn({ method: "GET" }).validator(idSchema).handler(createSsrRpc("360b5d0dac3f25b0b4b525917f3925b73dd02a3596d0c36a27307ec961b976f9"));
var browseSchema = object({
	section: _enum([
		"popular",
		"season",
		"top",
		"trending"
	]),
	page: number().optional()
});
var fetchBrowse = createServerFn({ method: "GET" }).validator(browseSchema).handler(createSsrRpc("e33500c3c281a5f6a547ed12cbad641f00fef7783a8c9729d18cdbf27e717ed4"));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-2uA790DW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "Algo deu errado. Recarregue a página.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 bg-bg px-6 text-center text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-danger",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Algo deu errado"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-muted",
				children: errorMessage(error)
			})
		]
	});
}
function makeQueryClient() {
	return new QueryClient({ defaultOptions: { queries: {
		staleTime: 6e4,
		refetchOnWindowFocus: false,
		retry: 1
	} } });
}
function AuthProvider({ children }) {
	const [client] = (0, import_react.useState)(makeQueryClient);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
			theme: "dark",
			position: "bottom-center",
			toastOptions: {
				className: "font-sans",
				style: {
					background: "var(--color-elevated)",
					color: "var(--color-fg)",
					border: "1px solid var(--color-border)"
				}
			}
		})]
	});
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function Logo({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/",
		className: cn("flex items-baseline gap-2", className),
		"aria-label": "Hikari",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-2xl leading-none tracking-tight text-fg",
			children: "光"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[11px] font-medium tracking-[0.32em] text-muted uppercase",
			children: "Hikari"
		})]
	});
}
var NAV = [
	{
		to: "/",
		label: "Início",
		icon: House,
		match: (p) => p === "/"
	},
	{
		to: "/search",
		label: "Buscar",
		icon: Search,
		match: (p) => p.startsWith("/search") || p.startsWith("/browse")
	},
	{
		to: "/my-list",
		label: "Lista",
		icon: Bookmark,
		match: (p) => p.startsWith("/my-list")
	},
	{
		to: "/admin",
		label: "Admin",
		icon: Settings2,
		match: (p) => p.startsWith("/admin")
	}
];
function Shell() {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	if (pathname.startsWith("/watch")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-border bg-bg/85 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-14 max-w-6xl items-center justify-between gap-3 px-4 sm:h-16 sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "hidden items-center gap-1 md:flex",
							children: NAV.map((item) => {
								const active = item.match(pathname);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: item.to,
									className: cn("inline-flex h-11 items-center px-3 text-sm transition-colors", active ? "text-fg" : "text-muted hover:text-fg"),
									children: item.label
								}, item.to);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/search",
							className: "flex size-11 items-center justify-center rounded-md text-muted hover:bg-elevated hover:text-fg md:hidden",
							"aria-label": "Buscar",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-5" })
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto w-full max-w-6xl px-4 pb-24 sm:px-6 sm:pb-16",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mx-auto hidden max-w-6xl items-center justify-between px-6 py-8 text-xs text-subtle md:flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Hikari 光 — catálogo via AniList, com MyAnimeList como reserva." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "inline-flex items-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, { className: "size-3.5" }), "Trailers e episódios com URL própria"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-40 border-t border-border bg-bg/95 backdrop-blur-md md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid grid-cols-4",
					children: NAV.map((item) => {
						const active = item.match(pathname);
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: cn("flex min-h-14 flex-col items-center justify-center gap-0.5 text-[10px] tracking-wide uppercase", active ? "text-fg" : "text-subtle"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), item.label]
						}) }, item.to);
					})
				})
			})
		]
	});
}
var styles_default = "/assets/styles-BjGZcOUF.css";
var APP_NAME = "HIKARI";
var Route$9 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Hikari 光 — catálogo e streaming de animes. Temporada, populares, trailers e Minha Lista."
			},
			{
				name: "theme-color",
				content: "#09090b"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;600&family=Noto+Serif+JP:wght@500;600&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "pt-BR",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
function HomePending() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-10 pt-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "-mx-4 h-[28rem] animate-pulse bg-elevated sm:-mx-6 sm:h-[34rem]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rail",
			children: Array.from({ length: 8 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimeCardSkeleton, {}, i))
		})]
	});
}
var $$splitComponentImporter$8 = () => import("./routes-BalxqJQj.mjs");
var $$splitErrorComponentImporter = () => import("./routes-CqEdItT2.mjs");
var Route$8 = createFileRoute("/")({
	loader: () => fetchHomeCatalog(),
	pendingComponent: HomePending,
	errorComponent: lazyRouteComponent($$splitErrorComponentImporter, "errorComponent"),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./admin-rRckGftk.mjs");
var Route$7 = createFileRoute("/admin")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./my-list-C_eOQlzc.mjs");
var Route$6 = createFileRoute("/my-list")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./search-I0L7v_9e.mjs");
var Route$5 = createFileRoute("/search")({
	validateSearch: (raw) => ({
		q: typeof raw.q === "string" ? raw.q : "",
		genre: typeof raw.genre === "string" ? raw.genre : "",
		year: typeof raw.year === "string" ? raw.year : "",
		format: typeof raw.format === "string" ? raw.format : "",
		status: typeof raw.status === "string" ? raw.status : "",
		sort: typeof raw.sort === "string" ? raw.sort : "TRENDING_DESC"
	}),
	loaderDeps: ({ search }) => search,
	loader: async ({ deps }) => {
		const [result, home] = await Promise.all([searchCatalog({ data: {
			...deps,
			page: 1
		} }), fetchHomeCatalog()]);
		return {
			result,
			genres: home.genres
		};
	},
	pendingComponent: SearchPending,
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
function SearchPending() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-3 pt-20 sm:grid-cols-4 lg:grid-cols-6",
		children: Array.from({ length: 12 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimeCardSkeleton, {}, i))
	});
}
var $$splitComponentImporter$4 = () => import("./admin.index-DKkfdHNd.mjs");
var Route$4 = createFileRoute("/admin/")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./admin._id-wgF3kPBt.mjs");
var Route$3 = createFileRoute("/admin/$id")({
	validateSearch: (raw) => ({ importId: typeof raw.importId === "string" ? raw.importId : "" }),
	loaderDeps: ({ search }) => ({ importId: search.importId }),
	loader: async ({ params, deps }) => {
		const fetchId = params.id === "new" ? deps.importId : params.id;
		if (!fetchId || fetchId.startsWith("local-")) return { remote: null };
		try {
			return { remote: await fetchAnimeDetail({ data: { id: fetchId } }) };
		} catch {
			return { remote: null };
		}
	},
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./anime._id-eyVHfARl.mjs");
var Route$2 = createFileRoute("/anime/$id")({
	loader: async ({ params }) => {
		if (params.id.startsWith("local-")) return { remote: null };
		return { remote: await fetchAnimeDetail({ data: { id: params.id } }) };
	},
	pendingComponent: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 pt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "-mx-4 h-52 animate-pulse bg-elevated sm:-mx-6" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-2/3 animate-pulse rounded bg-elevated" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-24 animate-pulse rounded bg-elevated" })
		]
	}),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./browse._section-CGITJ3zs.mjs");
var Route$1 = createFileRoute("/browse/$section")({
	loader: async ({ params }) => {
		const section = [
			"popular",
			"season",
			"top",
			"trending"
		].includes(params.section) ? params.section : "popular";
		return {
			result: await fetchBrowse({ data: {
				section,
				page: 1
			} }),
			section
		};
	},
	pendingComponent: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-3 pt-20 sm:grid-cols-4 lg:grid-cols-6",
		children: Array.from({ length: 12 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimeCardSkeleton, {}, i))
	}),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./watch._id-FlIkhc9z.mjs");
var Route = createFileRoute("/watch/$id")({
	validateSearch: (raw) => ({ ep: typeof raw.ep === "string" ? raw.ep : "" }),
	loader: async ({ params }) => {
		if (params.id.startsWith("local-")) return { remote: null };
		return { remote: await fetchAnimeDetail({ data: { id: params.id } }) };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$8.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$9
});
var AdminRoute = Route$7.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => Route$9
});
var MyListRoute = Route$6.update({
	id: "/my-list",
	path: "/my-list",
	getParentRoute: () => Route$9
});
var SearchRoute = Route$5.update({
	id: "/search",
	path: "/search",
	getParentRoute: () => Route$9
});
var AdminIndexRoute = Route$4.update({
	id: "/",
	path: "/",
	getParentRoute: () => AdminRoute
});
var AdminIdRoute = Route$3.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => AdminRoute
});
var AnimeIdRoute = Route$2.update({
	id: "/anime/$id",
	path: "/anime/$id",
	getParentRoute: () => Route$9
});
var BrowseSectionRoute = Route$1.update({
	id: "/browse/$section",
	path: "/browse/$section",
	getParentRoute: () => Route$9
});
var WatchIdRoute = Route.update({
	id: "/watch/$id",
	path: "/watch/$id",
	getParentRoute: () => Route$9
});
var AdminRouteChildren = {
	AdminIdRoute,
	AdminIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	AdminRoute: AdminRoute._addFileChildren(AdminRouteChildren),
	MyListRoute,
	SearchRoute,
	AnimeIdRoute,
	BrowseSectionRoute,
	WatchIdRoute
};
var routeTree = Route$9._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { Route$3 as a, HomePending as c, AnimeCardSkeleton as d, Route$2 as i, searchCatalog as l, Route as n, Route$5 as o, Route$1 as r, Route$8 as s, router_exports as t, AnimeCard as u };
