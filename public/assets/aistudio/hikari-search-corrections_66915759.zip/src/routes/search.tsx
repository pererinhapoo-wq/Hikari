import {
  createFileRoute,
  Link,
} from "@tanstack/react-router";

import {
  ChevronLeft,
  Mic2,
  UserRound,
  Lock,
  Search as SearchIcon,
  SlidersHorizontal,
  Users,
  X,
} from "lucide-react";

import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";

import {
  fetchGenres,
  searchCatalog,
} from "@/lib/api";

import {
  FORMAT_PT,
  GENRE_PT,
  SORT_OPTIONS,
  STATUS_PT,
} from "@/lib/labels";

import { overlayList } from "@/lib/overlay";
import { searchUsers, type SearchUserItem } from "@/lib/profile.functions";
import { buildCleanCanonical, DEFAULT_OG_IMAGE } from "@/lib/seo";
import { useHikariStore } from "@/lib/store";

import {
  AnimeCard,
  AnimeCardSkeleton,
} from "@/components/anime-card";
import { SearchCategorySelector, type SearchCategory } from "@/components/search/SearchCategorySelector";
import { searchCharacters, searchPeople, type SearchCharacterItem, type SearchPersonItem } from "@/lib/search-entities";
import { cn } from "@/lib/utils";

import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { NativeSelect } from "@/components/ui/native-select";

const YEARS = Array.from(
  { length: 37 },
  (_, i) =>
    String(2026 - i),
);

type Search = {
  q?: string;
  genre?: string;
  year?: string;
  format?: string;
  status?: string;
  sort?: string;
  page?: number;
  adult?: boolean;
  tab?: SearchCategory;
};

export const Route =
  createFileRoute("/search")({
    validateSearch: (
      raw: Record<string, unknown>,
    ): Search => ({
      q:
        typeof raw.q === "string" &&
        raw.q
          ? raw.q
          : undefined,

      genre:
        typeof raw.genre === "string" &&
        raw.genre
          ? raw.genre
          : undefined,

      year:
        typeof raw.year === "string" &&
        raw.year
          ? raw.year
          : undefined,

      format:
        typeof raw.format === "string" &&
        raw.format
          ? raw.format
          : undefined,

      status:
        typeof raw.status === "string" &&
        raw.status
          ? raw.status
          : undefined,

      sort:
        typeof raw.sort === "string" &&
        raw.sort
          ? raw.sort
          : undefined,

      page:
        typeof raw.page === "string" &&
        /^\d+$/.test(raw.page)
          ? Math.max(
              1,
              Number(raw.page),
            )
          : undefined,

      adult:
        raw.adult === true ||
        raw.adult === "true"
          ? true
          : undefined,

      tab:
        raw.tab === "users" || raw.tab === "characters" || raw.tab === "people"
          ? raw.tab
          : undefined,
    }),

    loaderDeps: ({
      search,
    }) => search,

    loader: async ({
      deps,
    }) => {
      const [
        result,
        genres,
      ] = await Promise.all([
        searchCatalog({
          data: {
            ...deps,
            page:
              deps.page ?? 1,
          },
        }),

        fetchGenres(),
      ]);

      return {
        result,
        genres,
      };
    },

    head: ({ match }) => {
      const search = (match?.search ?? {}) as Search;
      const hasQueryOrFilter = Boolean(
        search.q ||
        search.genre ||
        search.year ||
        search.format ||
        search.status ||
        search.sort ||
        (search.page && search.page > 1)
      );

      const title = search.q
        ? `Buscar "${search.q}" no catálogo — HIKARI`
        : search.genre
          ? `Animes do gênero ${search.genre} — HIKARI`
          : "Buscar animes no catálogo — HIKARI";

      const description = search.q
        ? `Resultados da busca por "${search.q}" no catálogo do HIKARI. Assista e explore informações completas de animes.`
        : "Filtre e encontre animes por gênero, ano de lançamento, temporada e formato no catálogo completo do HIKARI.";

      const canonicalUrl = buildCleanCanonical("/search");

      const meta = [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:image", content: DEFAULT_OG_IMAGE },
        { property: "og:url", content: canonicalUrl },
        { property: "og:locale", content: "pt_BR" },
        { property: "og:site_name", content: "HIKARI" },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:title", content: title },
        { name: "twitter:description", content: description },
        { name: "twitter:image", content: DEFAULT_OG_IMAGE },
        ...(hasQueryOrFilter
          ? [{ name: "robots", content: "noindex, follow" }]
          : []),
      ];

      return {
        links: [
          {
            rel: "canonical",
            href: canonicalUrl,
          },
        ],
        meta,
      };
    },

    pendingComponent:
      SearchPending,

    component:
      SearchPage,
  });

function SearchPending() {
  return (
    <div className="grid grid-cols-2 gap-3 pt-6 sm:grid-cols-4 lg:grid-cols-6">
      {Array.from(
        { length: 12 },
        (_, i) => (
          <div
            key={i}
            className="[&>div]:w-full"
          >
            <AnimeCardSkeleton />
          </div>
        ),
      )}
    </div>
  );
}

function SearchPage() {
  const search =
    Route.useSearch();

  const navigate =
    Route.useNavigate();

  const {
    result,
    genres,
  } =
    Route.useLoaderData();

  const locals =
    useHikariStore(
      (s) => s.animes,
    );

  /*
   * =========================================================
   * RELOAD REAL DA PÁGINA
   * =========================================================
   */

  const [
    clearingOnReload,
    setClearingOnReload,
  ] = useState(() => {
    if (
      typeof window === "undefined"
    ) {
      return false;
    }

    const navigation =
      window.performance.getEntriesByType(
        "navigation",
      )[0] as
        | PerformanceNavigationTiming
        | undefined;

    const alreadyHandled =
      Boolean(
        (
          window as Window & {
            __hikariSearchReloadHandled?: boolean;
          }
        ).__hikariSearchReloadHandled,
      );

    if (
      navigation?.type === "reload" &&
      !alreadyHandled
    ) {
      (
        window as Window & {
          __hikariSearchReloadHandled?: boolean;
        }
      ).__hikariSearchReloadHandled =
        true;

      return true;
    }

    return false;
  });

  /*
   * =========================================================
   * CAMPO DE BUSCA
   * =========================================================
   */

  const [
    draft,
    setDraft,
  ] = useState(() =>
    search.q ?? "",
  );

  /*
   * Guarda a primeira execução do efeito de sincronização.
   *
   * Isso impede que o React apague "jujut" logo depois
   * que o usuário começa a digitar.
   */

  const firstSearchSync =
    useRef(true);

  const [
    filtersOpen,
    setFiltersOpen,
  ] = useState(false);

  const currentPage =
    search.page ?? 1;

  const [remoteAnimeItems, setRemoteAnimeItems] = useState<typeof result.items>([]);
  useEffect(() => {
    if (currentPage === 1) {
      setRemoteAnimeItems(result.items);
      return;
    }
    setRemoteAnimeItems((previous) => {
      const seen = new Set(previous.map((anime) => anime.id));
      return [...previous, ...result.items.filter((anime) => !seen.has(anime.id))];
    });
  }, [result.items, currentPage]);


  const activeTab: SearchCategory = search.tab ?? "animes";

  const handleTabChange = (nextTab: SearchCategory) => {
    void navigate({
      search: { ...search, tab: nextTab === "animes" ? undefined : nextTab, page: 1 },
      replace: true,
    });
  };

  /*
   * =========================================================
   * PESQUISA DE USUÁRIOS (ETAPA 12)
   * =========================================================
   */

  const [userResults, setUserResults] = useState<SearchUserItem[]>([]);
  const [usersPage, setUsersPage] = useState(1);
  const [hasMoreUsers, setHasMoreUsers] = useState(false);
  const [usersLoading, setUsersLoading] = useState(false);
  const [usersLoadingMore, setUsersLoadingMore] = useState(false);
  const [usersError, setUsersError] = useState<string | null>(null);
  const isFetchingMoreRef = useRef(false);
  const [characterResults, setCharacterResults] = useState<SearchCharacterItem[]>([]);
  const [peopleResults, setPeopleResults] = useState<SearchPersonItem[]>([]);
  const [entityLoading, setEntityLoading] = useState(false);
  const [entityHasNext, setEntityHasNext] = useState(false);
  const [entityPage, setEntityPage] = useState(1);
  const entitySentinelRef = useRef<HTMLDivElement>(null);
  const animeSentinelRef = useRef<HTMLDivElement>(null);
  const userSentinelRef = useRef<HTMLDivElement>(null);

  let userQueryClean = draft.trim();
  if (userQueryClean.startsWith("@")) {
    userQueryClean = userQueryClean.slice(1).trim();
  }

  useEffect(() => {
    if (activeTab !== "users") {
      return;
    }

    let clean = draft.trim();
    if (clean.startsWith("@")) {
      clean = clean.slice(1).trim();
    }

    if (clean.length < 2) {
      setUserResults([]);
      setHasMoreUsers(false);
      setUsersLoading(false);
      setUsersError(null);
      return;
    }

    setUsersLoading(true);
    setUsersError(null);

    const timer = window.setTimeout(async () => {
      try {
        const results = await searchUsers({
          data: {
            query: clean,
            page: 1,
            limit: 20,
          },
        });
        setUserResults(results);
        setUsersPage(1);
        setHasMoreUsers(results.length >= 20);
      } catch (err) {
        console.error("Erro ao buscar usuários:", err);
        setUsersError("Não foi possível carregar os usuários. Tente novamente.");
        setUserResults([]);
        setHasMoreUsers(false);
      } finally {
        setUsersLoading(false);
      }
    }, 350);

    return () => window.clearTimeout(timer);
  }, [activeTab, draft]);

  const handleLoadMoreUsers = async () => {
    if (usersLoadingMore || isFetchingMoreRef.current || !hasMoreUsers) {
      return;
    }

    let clean = draft.trim();
    if (clean.startsWith("@")) {
      clean = clean.slice(1).trim();
    }
    if (clean.length < 2) return;

    const nextPage = usersPage + 1;
    isFetchingMoreRef.current = true;
    setUsersLoadingMore(true);

    try {
      const moreUsers = await searchUsers({
        data: {
          query: clean,
          page: nextPage,
          limit: 20,
        },
      });

      setUserResults((prev) => {
        const existingIds = new Set(prev.map((u) => u.userId));
        const newUnique = moreUsers.filter((u) => !existingIds.has(u.userId));
        return [...prev, ...newUnique];
      });

      setUsersPage(nextPage);
      setHasMoreUsers(moreUsers.length >= 20);
    } catch (err) {
      console.error("Erro ao carregar mais usuários:", err);
    } finally {
      isFetchingMoreRef.current = false;
      setUsersLoadingMore(false);
    }
  };

  useEffect(() => {
    if (activeTab !== "characters" && activeTab !== "people") return;
    const clean = draft.trim();
    if (clean.length < 2) {
      setCharacterResults([]); setPeopleResults([]); setEntityHasNext(false); setEntityPage(1);
      return;
    }
    let cancelled = false;
    setEntityLoading(true);
    const timer = window.setTimeout(async () => {
      try {
        const result = activeTab === "characters"
          ? await searchCharacters(clean, 1, 18)
          : await searchPeople(clean, 1, 18);
        if (cancelled) return;
        if (activeTab === "characters") setCharacterResults(result.items as SearchCharacterItem[]);
        else setPeopleResults(result.items as SearchPersonItem[]);
        setEntityHasNext(result.hasNext); setEntityPage(1);
      } catch {
        if (!cancelled) { setCharacterResults([]); setPeopleResults([]); setEntityHasNext(false); }
      } finally { if (!cancelled) setEntityLoading(false); }
    }, 300);
    return () => { cancelled = true; window.clearTimeout(timer); };
  }, [activeTab, draft]);

  const loadMoreEntities = async () => {
    if (entityLoading || !entityHasNext || (activeTab !== "characters" && activeTab !== "people")) return;
    const nextPage = entityPage + 1;
    setEntityLoading(true);
    try {
      const result = activeTab === "characters"
        ? await searchCharacters(draft.trim(), nextPage, 18)
        : await searchPeople(draft.trim(), nextPage, 18);
      if (activeTab === "characters") setCharacterResults((prev) => { const seen = new Set(prev.map((x) => x.id)); return [...prev, ...(result.items as SearchCharacterItem[]).filter((x) => !seen.has(x.id))]; });
      else setPeopleResults((prev) => { const seen = new Set(prev.map((x) => x.id)); return [...prev, ...(result.items as SearchPersonItem[]).filter((x) => !seen.has(x.id))]; });
      setEntityPage(nextPage); setEntityHasNext(result.hasNext);
    } finally { setEntityLoading(false); }
  };

  /*
   * =========================================================
   * LIMPAR BUSCA SOMENTE NO RELOAD REAL
   * =========================================================
   *
   * O gênero e o tipo da busca são preservados.
   */

  useEffect(() => {
    if (!clearingOnReload) {
      return;
    }

    setDraft("");

    void navigate({
      search: {
        genre:
          search.genre,
        adult:
          search.adult,
      },
      replace: true,
    }).finally(() => {
      setClearingOnReload(false);
    });
  }, [
    clearingOnReload,
    navigate,
    search.genre,
    search.adult,
  ]);

  /*
   * =========================================================
   * SINCRONIZAR CAMPO COM A URL
   * =========================================================
   *
   * IMPORTANTE:
   * Não executamos esta sincronização na primeira montagem.
   *
   * Assim, o valor inicial do campo continua sendo o valor
   * correto e o usuário pode digitar normalmente.
   */

  useEffect(() => {
    if (
      firstSearchSync.current
    ) {
      firstSearchSync.current =
        false;

      return;
    }

    if (clearingOnReload) {
      return;
    }

    setDraft(
      search.q ?? "",
    );
  }, [
    search.q,
    clearingOnReload,
  ]);

  /*
   * =========================================================
   * BUSCA AUTOMÁTICA
   * =========================================================
   *
   * Não precisa apertar Enter.
   *
   * A partir de 2 caracteres, aguarda 700ms.
   */

  useEffect(() => {
    if (clearingOnReload) {
      return;
    }

    if (activeTab !== "animes") {
      return;
    }

    const q =
      draft.trim();

    /*
     * Não pesquisa uma única letra.
     */

    if (
      q.length > 0 &&
      q.length < 2
    ) {
      return;
    }

    const current =
      (
        search.q ?? ""
      ).trim();

    if (q === current) {
      return;
    }

    const timer =
      window.setTimeout(() => {
        void navigate({
          search: {
            ...search,
            q:
              q || undefined,
            page: 1,
          },
          replace: true,
        });
      }, 700);

    return () =>
      window.clearTimeout(
        timer,
      );
  }, [
    draft,
    navigate,
    search,
    clearingOnReload,
    activeTab,
  ]);

  /*
   * =========================================================
   * RESULTADOS
   * =========================================================
   */

  const items =
    useMemo(() => {
      if (clearingOnReload) {
        return [];
      }

      const q =
        (
          search.q ?? ""
        )
          .trim()
          .toLowerCase();

      /*
       * Animes locais somente na primeira página.
       */

      const localHits =
        currentPage === 1
          ? overlayList(
              [],
              locals,
            ).filter(
              (anime) => {
                const isHentai =
                  anime.genres?.some(
                    (genre) =>
                      genre
                        .trim()
                        .toLowerCase() ===
                      "hentai",
                  ) ?? false;

                /*
                 * Busca adulta:
                 * somente Hentai.
                 *
                 * Busca normal:
                 * exclui Hentai.
                 */

                if (
                  search.adult
                ) {
                  if (
                    !isHentai
                  ) {
                    return false;
                  }
                } else if (
                  isHentai
                ) {
                  return false;
                }

                if (q) {
                  const titleStr =
                    `${anime.titles?.romaji || ""} ${anime.titles?.english || ""} ${anime.titles?.native || ""}`
                      .normalize("NFD")
                      .replace(/[\u0300-\u036f]/g, "")
                      .toLowerCase();
                  const normalizedQ = q
                    .normalize("NFD")
                    .replace(/[\u0300-\u036f]/g, "")
                    .toLowerCase();

                  const matchesDirect = titleStr.includes(normalizedQ);
                  const matchesWords = normalizedQ
                    .split(/\s+/)
                    .every((word) => titleStr.includes(word));

                  if (!matchesDirect && !matchesWords) {
                    return false;
                  }
                }

                if (
                  search.genre &&
                  !anime.genres.includes(
                    search.genre,
                  )
                ) {
                  return false;
                }

                return true;
              },
            )
          : [];

      const remote =
        overlayList(
          remoteAnimeItems,
          locals,
        ).filter(
          (anime) => {
            const isHentai =
              anime.genres?.some(
                (genre) =>
                  genre
                    .trim()
                    .toLowerCase() ===
                  "hentai",
              ) ?? false;

            /*
             * Proteção adicional no resultado remoto.
             *
             * Isso garante que nenhum conteúdo +18
             * apareça na busca normal, e que a busca
             * adulta permaneça somente em Hentai.
             */

            return search.adult
              ? isHentai
              : !isHentai;
          },
        );

      const seen =
        new Set(
          localHits.map(
            (anime) =>
              anime.id,
          ),
        );

      return [
        ...localHits,
        ...remote.filter(
          (anime) =>
            !seen.has(
              anime.id,
            ),
        ),
      ];
    }, [
      currentPage,
      locals,
      remoteAnimeItems,
      search.q,
      search.genre,
      search.adult,
      clearingOnReload,
    ]);

  /*
   * =========================================================
   * FILTROS
   * =========================================================
   */

  function apply(
    next: Partial<Search>,
  ) {
    void navigate({
      search: {
        ...search,
        ...next,
        page: 1,
      },
    });
  }

  const genreOptions =
    genres.length
      ? genres
      : Object.keys(
          GENRE_PT,
        );

  const hasAnimes =
    items.length > 0;

  const hasQuery =
    Boolean(
      search.q?.trim() ||
      search.genre,
    );

  const activeFilterCount = [
    search.genre,
    search.year,
    search.format,
    search.status,
    search.sort,
  ].filter(Boolean).length;

  useEffect(() => {
    const target = activeTab === "animes" ? animeSentinelRef.current : activeTab === "users" ? userSentinelRef.current : entitySentinelRef.current;
    if (!target || typeof IntersectionObserver === "undefined") return;
    const observer = new IntersectionObserver((entries) => {
      if (!entries.some((entry) => entry.isIntersecting)) return;
      if (activeTab === "animes" && result.hasNext) {
        void navigate({ search: { ...search, page: currentPage + 1 }, replace: true });
      } else if (activeTab === "users" && hasMoreUsers) {
        void handleLoadMoreUsers();
      } else if ((activeTab === "characters" || activeTab === "people") && entityHasNext) {
        void loadMoreEntities();
      }
    }, { rootMargin: "500px 0px" });
    observer.observe(target);
    return () => observer.disconnect();
  }, [activeTab, result.hasNext, currentPage, search, navigate, hasMoreUsers, usersLoadingMore, entityHasNext, entityLoading, draft]);

  /*
   * =========================================================
   * BLOQUEIO DURANTE RELOAD
   * =========================================================
   *
   * Não mostra "Pesquise um anime" durante o reload.
   */

  if (clearingOnReload) {
    return (
      <div className="space-y-6 pt-6">

        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() =>
              window.history.back()
            }
          >
            <ChevronLeft className="size-4" />
            Voltar
          </Button>
        </div>

        <SearchPending />

      </div>
    );
  }

  /*
   * =========================================================
   * RENDER
   * =========================================================
   */

  return (
    <div className="space-y-6 pt-6">

      {/* =====================================================
          VOLTAR
      ====================================================== */}

      <div>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() =>
            window.history.back()
          }
        >
          <ChevronLeft className="size-4" />
          Voltar
        </Button>
      </div>

      {/* =====================================================
          BARRA DE PESQUISA COMPACTA E ELEGANTE (INSPIRADA NO BINGEBANG)
      ====================================================== */}
      <div className="relative flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
        <div className="relative flex flex-1 items-center gap-1.5 sm:gap-2 rounded-xl border border-white/10 bg-surface/80 p-1 sm:p-1.5 shadow-sm transition-colors focus-within:border-purple-400/40 focus-within:bg-elevated/90">
          {/* Seletor de Categoria com alinhamento à esquerda correto para evitar corte fora da tela */}
          <SearchCategorySelector
            category={activeTab}
            onChange={(nextCat) => handleTabChange(nextCat)}
            size="md"
            align="left"
          />

          <div className="h-5 w-px bg-white/10 shrink-0" aria-hidden="true" />

          <div className="relative flex-1 flex items-center">
            <SearchIcon className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 sm:size-4 -translate-y-1/2 text-zinc-400" />
            <input
              type="search"
              enterKeyHint="go"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  // Desfoca o input imediatamente para remover foco e evitar anel roxo preso no mobile
                  (e.currentTarget as HTMLInputElement).blur();
                  const q = draft.trim();
                  void navigate({
                    search: {
                      ...search,
                      q: q || undefined,
                      page: 1,
                    },
                    replace: true,
                  });
                }
              }}
              placeholder={
                activeTab === "animes" ? "Buscar animes..." : activeTab === "users" ? "Buscar usuários..." : activeTab === "characters" ? "Buscar personagens..." : "Buscar People..."
              }
              className="h-9 sm:h-10 w-full rounded-lg border-0 bg-transparent pl-8 sm:pl-9 pr-8 text-xs sm:text-sm text-zinc-100 outline-none placeholder:text-zinc-500 transition-colors [&::-webkit-search-cancel-button]:hidden [&::-webkit-search-decoration]:hidden"
              aria-label={
                `Buscar ${activeTab}`
              }
            />
            {draft.length > 0 && (
              <button
                type="button"
                onClick={() => setDraft("")}
                className="absolute right-1.5 top-1/2 flex size-6 -translate-y-1/2 items-center justify-center rounded-full text-zinc-400 hover:bg-white/10 hover:text-fg transition-colors"
                aria-label="Limpar busca"
              >
                <X className="size-3.5" />
              </button>
            )}
          </div>
        </div>

        {activeTab === "animes" && (
          <Button
            type="button"
            variant="outline"
            onClick={() => setFiltersOpen((value) => !value)}
            className={cn(
              "h-9 sm:h-11 shrink-0 rounded-xl px-3 sm:px-3.5 text-xs sm:text-sm font-semibold transition-all border",
              filtersOpen || activeFilterCount > 0
                ? "border-purple-500/40 bg-purple-500/15 text-[#c084fc] shadow-[0_0_12px_rgba(168,85,247,0.15)]"
                : "border-white/10 bg-surface/80 text-zinc-300 hover:bg-elevated hover:text-fg",
            )}
            aria-label="Filtros do catálogo"
          >
            <SlidersHorizontal className="size-3.5 sm:size-4 mr-1.5" />
            <span>Filtros</span>
            {activeFilterCount > 0 && (
              <span className="ml-1.5 flex size-4.5 items-center justify-center rounded-full bg-[#a855f7] text-[9px] font-bold text-white">
                {activeFilterCount}
              </span>
            )}
          </Button>
        )}
      </div>

      {/* =====================================================
          FILTROS (SOMENTE ABA ANIMES)
      ====================================================== */}

      {activeTab === "animes" && (
        <div
          className={
            filtersOpen
              ? "grid gap-3 sm:grid-cols-2 lg:grid-cols-4"
              : "hidden lg:grid lg:grid-cols-4 lg:gap-3"
          }
        >
          {/* GÊNERO */}
          <Field label="Gênero">
            <NativeSelect
              value={search.genre ?? ""}
              onChange={(e) =>
                apply({
                  genre: e.target.value || undefined,
                })
              }
            >
              <option value="">Todos</option>
              {genreOptions.map((genre) => (
                <option key={genre} value={genre}>
                  {GENRE_PT[genre] ?? genre}
                </option>
              ))}
            </NativeSelect>
          </Field>

          {/* ANO */}
          <Field label="Ano">
            <NativeSelect
              value={search.year ?? ""}
              onChange={(e) =>
                apply({
                  year: e.target.value || undefined,
                })
              }
            >
              <option value="">Qualquer</option>
              {YEARS.map((year) => (
                <option key={year} value={year}>
                  {year}
                </option>
              ))}
            </NativeSelect>
          </Field>

          {/* FORMATO */}
          <Field label="Formato">
            <NativeSelect
              value={search.format ?? ""}
              onChange={(e) =>
                apply({
                  format: e.target.value || undefined,
                })
              }
            >
              <option value="">Todos</option>
              {Object.entries(FORMAT_PT)
                .filter(([key]) =>
                  [
                    "TV",
                    "MOVIE",
                    "OVA",
                    "ONA",
                    "SPECIAL",
                    "TV_SHORT",
                  ].includes(key),
                )
                .map(([key, value]) => (
                  <option key={key} value={key}>
                    {value}
                  </option>
                ))}
            </NativeSelect>
          </Field>

          {/* STATUS */}
          <Field label="Status">
            <NativeSelect
              value={search.status ?? ""}
              onChange={(e) =>
                apply({
                  status: e.target.value || undefined,
                })
              }
            >
              <option value="">Todos</option>
              {Object.entries(STATUS_PT).map(([key, value]) => (
                <option key={key} value={key}>
                  {value}
                </option>
              ))}
            </NativeSelect>
          </Field>

          {/* ORDENAR */}
          <Field label="Ordenar" className="lg:col-span-2">
            <NativeSelect
              value={search.sort ?? "TRENDING_DESC"}
              onChange={(e) =>
                apply({
                  sort: e.target.value || undefined,
                })
              }
            >
              {SORT_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </NativeSelect>
          </Field>
        </div>
      )}

      {/* =====================================================
          CONTEÚDO DA ABA DE ANIMES
      ====================================================== */}

      {activeTab === "animes" && (
        <>
          {hasQuery && hasAnimes && (
            <section className="space-y-5">
              <div className="flex items-end justify-between gap-3">
                <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1">
                  <h1 className="font-display text-2xl tracking-tight sm:text-3xl">
                    Resultados da busca
                  </h1>
                  <span className="text-sm text-muted">
                    {items.length}{" "}
                    {items.length === 1
                      ? "anime encontrado"
                      : "animes encontrados"}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-3 items-stretch gap-2.5 sm:grid-cols-4 lg:grid-cols-6">
                {items.map((anime) => (
                  <div key={anime.id} className="min-w-0 [&>article]:w-full">
                    <AnimeCard anime={anime} size="lg" showScoreBadge />
                  </div>
                ))}
              </div>
              <div ref={animeSentinelRef} className="h-8" aria-hidden="true" />
              {result.hasNext && <p className="py-3 text-center text-xs text-muted">Carregando mais animes automaticamente...</p>}


            </section>
          )}

          {!hasQuery && (
            <div className="py-20 text-center">
              <SearchIcon className="mx-auto size-8 text-subtle" />
              <p className="mt-4 font-display text-2xl">
                Pesquise um anime
              </p>
              <p className="mt-2 text-sm text-muted">
                Digite o nome do anime para ver os resultados.
              </p>
            </div>
          )}

          {hasQuery && !hasAnimes && (
            <div className="py-20 text-center">
              <p className="font-display text-2xl">Nada encontrado</p>
              <p className="mt-2 text-sm text-muted">
                Tente outro título ou limpe os filtros.
              </p>
              <Link
                to="/search"
                className="mt-4 inline-block text-sm text-fg underline"
              >
                Limpar busca
              </Link>
            </div>
          )}
        </>
      )}

      {/* =====================================================
          CONTEÚDO DA ABA DE USUÁRIOS (ETAPA 12)
      ====================================================== */}

      {activeTab === "users" && (
        <section className="space-y-5">
          {/* Carregamento inicial de usuários */}
          {usersLoading && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              {Array.from({ length: 6 }).map((_, i) => (
                <div
                  key={i}
                  className="flex items-center gap-3 rounded-2xl border border-white/[0.06] bg-white/[0.02] p-3.5 sm:p-4 animate-pulse"
                >
                  <div className="size-11 sm:size-12 shrink-0 rounded-xl bg-white/[0.05]" />
                  <div className="flex-1 space-y-2">
                    <div className="h-4 w-32 rounded bg-white/[0.05]" />
                    <div className="h-3 w-20 rounded bg-white/[0.05]" />
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Erro ao buscar usuários */}
          {!usersLoading && usersError && (
            <div className="py-20 text-center">
              <p className="font-display text-2xl text-red-400">
                Erro na busca
              </p>
              <p className="mt-2 text-sm text-muted">{usersError}</p>
            </div>
          )}

          {/* Menos de dois caracteres */}
          {!usersLoading && !usersError && userQueryClean.length < 2 && (
            <div className="py-20 text-center">
              <Users className="mx-auto size-8 text-subtle" />
              <p className="mt-4 font-display text-2xl">
                Pesquise um usuário
              </p>
              <p className="mt-2 text-sm text-muted">
                Digite o @username ou nome de exibição (mínimo de 2 caracteres) para encontrar membros da comunidade.
              </p>
            </div>
          )}

          {/* Nenhum usuário encontrado */}
          {!usersLoading &&
            !usersError &&
            userQueryClean.length >= 2 &&
            userResults.length === 0 && (
              <div className="py-20 text-center">
                <Users className="mx-auto size-8 text-subtle" />
                <p className="mt-4 font-display text-2xl">
                  Nenhum usuário encontrado
                </p>
                <p className="mt-2 text-sm text-muted">
                  Não encontramos membros correspondentes a &quot;{draft.trim()}&quot;. Tente outro username ou nome.
                </p>
              </div>
            )}

          {/* Resultados de usuários encontrados */}
          {!usersLoading && !usersError && userResults.length > 0 && (
            <>
              <div className="flex items-end justify-between gap-3">
                <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1">
                  <h1 className="font-display text-2xl tracking-tight sm:text-3xl">
                    Resultados da busca
                  </h1>
                  <span className="text-sm text-muted">
                    {userResults.length}{" "}
                    {userResults.length === 1
                      ? "usuário encontrado"
                      : "usuários encontrados"}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {userResults.map((person) => {
                  const avatarLetter = (
                    person.displayName ||
                    person.nick ||
                    "U"
                  )
                    .charAt(0)
                    .toUpperCase();

                  return (
                    <div
                      key={person.userId}
                      className="flex items-center justify-between gap-2.5 rounded-xl border border-white/10 bg-surface/70 p-2.5 sm:p-3 transition-all hover:border-purple-500/30 hover:bg-elevated hover:shadow-[0_0_20px_rgba(168,85,247,0.12)]"
                    >
                      {/* Ao selecionar um usuário, abrir o Perfil novo do Hikari (/profile/$nick) */}
                      <Link
                        to="/profile/$nick"
                        params={{ nick: person.nick }}
                        className="flex items-center gap-2.5 min-w-0 flex-1 group"
                      >
                        <div className="flex size-10 sm:size-10.5 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-[#161424] font-semibold text-xs sm:text-sm text-[#c084fc] ring-1 ring-purple-500/20 group-hover:ring-purple-500/40 transition-all">
                          {person.avatarUrl ? (
                            <img
                              src={person.avatarUrl}
                              alt=""
                              className="size-full object-cover"
                            />
                          ) : (
                            <span>{avatarLetter}</span>
                          )}
                        </div>

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <p className="truncate text-xs sm:text-sm font-semibold text-fg transition-colors group-hover:text-[#c084fc]">
                              {person.displayName || person.nick}
                            </p>
                            {person.accountType === "private" && (
                              <span
                                className="inline-flex items-center gap-0.5 rounded bg-white/[0.06] px-1 py-0.2 text-[9px] font-medium text-zinc-400 border border-white/[0.08]"
                                title="Conta privada"
                              >
                                <Lock className="size-2 text-zinc-400" />
                                <span>Privada</span>
                              </span>
                            )}
                            {person.isFollowing && (
                              <span className="inline-flex items-center rounded bg-[#a855f7]/15 px-1 py-0.2 text-[9px] font-semibold text-[#c084fc] border border-purple-500/20">
                                Seguindo
                              </span>
                            )}
                            {person.isOwner && (
                              <span className="inline-flex items-center rounded bg-white/10 px-1 py-0.2 text-[9px] font-semibold text-zinc-300">
                                Você
                              </span>
                            )}
                          </div>
                          <p className="truncate text-[10px] sm:text-xs text-muted">
                            @{person.nick}
                          </p>
                        </div>
                      </Link>

                      <Link
                        to="/profile/$nick"
                        params={{ nick: person.nick }}
                        className="shrink-0 rounded-lg border border-purple-500/25 bg-purple-500/10 px-2.5 py-1 text-xs font-semibold text-[#c084fc] transition-all hover:bg-[#a855f7] hover:text-white"
                      >
                        Ver perfil
                      </Link>
                    </div>
                  );
                })}
              </div>

              <div ref={userSentinelRef} className="h-8" aria-hidden="true" />
              {usersLoadingMore && <p className="py-3 text-center text-xs text-muted">Carregando mais usuários...</p>}
            </>
          )}
        </section>
      )}

      {(activeTab === "characters" || activeTab === "people") && (
        <section className="space-y-4">
          <h1 className="font-display text-2xl">{activeTab === "characters" ? "Personagens" : "People"}</h1>
          {entityLoading && characterResults.length === 0 && peopleResults.length === 0 && <p className="py-10 text-center text-sm text-muted">Pesquisando...</p>}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
            {(activeTab === "characters" ? characterResults : peopleResults).map((item) => {
              const person = item as SearchCharacterItem & SearchPersonItem;
              const animeId = person.anime?.id;
              const cardContent = (
                <>
                  <div className="aspect-[3/4] overflow-hidden rounded-xl bg-[#100e1b]">{person.image?.large || person.image?.medium ? <img src={person.image.large || person.image.medium || ""} alt="" loading="lazy" decoding="async" className="size-full object-cover" /> : <div className="flex size-full items-center justify-center text-muted">{activeTab === "characters" ? <UserRound /> : <Mic2 />}</div>}</div>
                  <div className="p-2"><p className="line-clamp-2 text-xs font-semibold text-fg group-hover:text-purple-300">{person.name.full}</p><p className="mt-1 line-clamp-1 text-[10px] text-muted">{person.role || (activeTab === "characters" ? "Personagem" : "Equipe técnica")}</p>{person.anime?.title && <p className="mt-1 line-clamp-1 text-[10px] text-zinc-500">{person.anime.title}</p>}</div>
                </>
              );
              return animeId ? (
                <Link key={person.id} to="/anime/$id" params={{ id: String(animeId) }} className="group overflow-hidden rounded-xl border border-white/10 bg-surface/70">{cardContent}</Link>
              ) : (
                <div key={person.id} className="group overflow-hidden rounded-xl border border-white/10 bg-surface/70">{cardContent}</div>
              );
            })}
          </div>
          <div ref={entitySentinelRef} className="h-8" />
          {entityLoading && <p className="py-3 text-center text-xs text-muted">Carregando mais resultados...</p>}
          {!entityLoading && !entityHasNext && (activeTab === "characters" ? characterResults.length : peopleResults.length) === 0 && <p className="py-12 text-center text-sm text-muted">Nenhum resultado encontrado.</p>}
        </section>
      )}

    </div>
  );
}

function Field({
  label,
  children,
  className,
}: {
  label: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label
      className={
        className
      }
    >
      <Label className="mb-1.5 block">
        {label}
      </Label>

      {children}
    </label>
  );
  }
