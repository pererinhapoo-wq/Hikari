import { Link } from "@tanstack/react-router";
import { ArrowLeft, Film } from "lucide-react";
import type { UserAnimeTrackingItem, TrackingStatus } from "@/types/profile-tracking";

const STATUS_LABEL: Record<TrackingStatus, string> = {
  watching: "Assistindo",
  completed: "Concluídos",
  on_hold: "Em espera",
  dropped: "Abandonados",
  planning: "Planejados",
};

interface Props {
  items: UserAnimeTrackingItem[];
  status: TrackingStatus;
}

export function PublicProfileTrackingList({ items, status }: Props) {
  const filtered = items.filter((item) => item.status === status);

  return (
    <section className="relative mx-auto w-full max-w-7xl space-y-6 px-4 py-6 sm:px-6 lg:px-8">
      <div className="flex items-center gap-3 border-b border-white/[0.08] pb-5">
        <Link to="." search={{ status: undefined } as any} className="flex size-9 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] text-zinc-300 transition hover:bg-white/[0.08]" aria-label="Voltar ao perfil">
          <ArrowLeft className="size-4" />
        </Link>
        <div>
          <h2 className="text-xl font-bold text-white">Animes — {STATUS_LABEL[status]}</h2>
          <p className="text-xs text-zinc-400">{filtered.length} {filtered.length === 1 ? "anime" : "animes"}</p>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-white/[0.08] bg-white/[0.02] px-5 py-14 text-center">
          <Film className="size-8 text-zinc-500" />
          <p className="font-semibold text-zinc-200">Nenhum anime encontrado</p>
          <p className="text-sm text-zinc-500">Não há animes nesta categoria.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6">
          {filtered.map((item) => (
            <Link key={item.animeId} to="/anime/$id" params={{ id: item.animeId }} className="group min-w-0">
              <div className="relative aspect-[2/3] overflow-hidden rounded-xl border border-white/10 bg-[#100e1b]">
                {item.cover ? <img src={item.cover} alt={item.title} loading="lazy" decoding="async" className="size-full object-cover transition duration-300 group-hover:scale-[1.03]" /> : <div className="flex size-full items-center justify-center text-2xl font-bold text-zinc-500">{item.title.slice(0, 1)}</div>}
                {typeof item.score === "number" && item.score > 0 && <span className="absolute right-2 top-2 rounded-md border border-white/10 bg-black/75 px-2 py-1 text-xs font-semibold text-violet-200">{item.score}/10</span>}
              </div>
              <p className="mt-2 line-clamp-2 text-sm font-medium text-zinc-200 group-hover:text-white">{item.title}</p>
              <p className="mt-1 text-xs text-zinc-500">{item.episodesWatched} {item.episodesWatched === 1 ? "episódio" : "episódios"}</p>
            </Link>
          ))}
        </div>
      )}
    </section>
  );
}
