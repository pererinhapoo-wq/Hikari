/**
 * Sign-in providers for HIKARI.
 *
 * Google OAuth is configured directly in Better Auth; the Google Cloud client
 * ID and secret are supplied through Vercel environment variables.
 */
export type AuthProvider = {
  providerId: "google";
  label: "Google";
};

export const AUTH_PROVIDERS: readonly AuthProvider[] = [
  { providerId: "google", label: "Google" },
];

// Kept as a compatibility alias for existing HIKARI components.
export const GROK_PROVIDERS = AUTH_PROVIDERS;
