import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Logo } from "@/components/logo";
import { GROK_PROVIDERS, authEnabled, signIn } from "@/lib/auth/client";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const [error, setError] = useState<string | null>(null);

  async function handleSignIn(providerId: string) {
    setError(null);
    try {
      await signIn(providerId, { callbackURL: "/account" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Não foi possível iniciar o login.");
    }
  }

  return (
    <main className="grid min-h-[70vh] place-items-center py-12">
      <div className="w-full max-w-sm rounded-xl bg-surface p-6 shadow-[var(--shadow-border)]">
        <div className="mb-6 flex justify-center">
          <Logo />
        </div>
        <h1 className="font-display text-2xl tracking-tight">Entrar na Conta</h1>
        <p className="mt-2 text-sm text-muted">Entre para usar sua conta no HIKARI.</p>
        <div className="mt-6 flex flex-col gap-2">
          {error ? (
            <p role="alert" className="rounded-md border border-danger/30 bg-danger/10 px-3 py-2 text-sm text-danger">
              {error}
            </p>
          ) : null}
          {authEnabled ? (
            GROK_PROVIDERS.map((p) => (
              <button
                key={p.providerId}
                type="button"
                onClick={() => void handleSignIn(p.providerId)}
                className="w-full cursor-pointer rounded-md border border-border px-4 py-3 text-sm font-medium transition-colors hover:bg-elevated"
              >
                Continuar com {p.label}
              </button>
            ))
          ) : (
            <p className="text-sm text-danger">O sistema de contas está desativado.</p>
          )}
        </div>
      </div>
    </main>
  );
}
