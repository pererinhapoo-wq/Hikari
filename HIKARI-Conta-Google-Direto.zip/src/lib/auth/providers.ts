/** Providers available in the HIKARI account screen. */
export type GrokProvider = {
  providerId: string;
  label: string;
};

export const GROK_PROVIDERS: readonly GrokProvider[] = [
  { providerId: "google", label: "Google" },
];
