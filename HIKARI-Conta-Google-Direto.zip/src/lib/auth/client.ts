import { createAuthClient } from "better-auth/react";
import { GROK_PROVIDERS } from "./providers";

/** Better Auth client for the HIKARI app. */
export const authClient = createAuthClient();

/** Sign-in UI is enabled unless explicitly disabled at build time. */
export const authEnabled = import.meta.env.VITE_AUTH_ENABLED !== "false";

/** Providers rendered by the account/login screens. */
export { GROK_PROVIDERS };

/** Start direct Google OAuth. Better Auth handles /api/auth/callback/google. */
export async function signIn(
  providerId: string,
  opts: { callbackURL?: string; errorCallbackURL?: string } = {},
): Promise<void> {
  if (providerId !== "google") {
    throw new Error("Provedor de login não disponível");
  }
  const { data, error } = await authClient.signIn.social({
    provider: "google",
    callbackURL: opts.callbackURL ?? "/",
    errorCallbackURL: opts.errorCallbackURL ?? "/login",
  });
  if (error) throw new Error(error.message ?? "Não foi possível iniciar o login");
  if (data?.url && typeof window !== "undefined") {
    window.location.href = data.url;
  }
}

/** Sign out of the current HIKARI account and return to the home page. */
export async function signOut(redirectTo = "/"): Promise<void> {
  const { error } = await authClient.signOut();
  if (error) throw new Error(error.message ?? "Não foi possível sair da conta");
  if (typeof window !== "undefined") window.location.href = redirectTo;
}
